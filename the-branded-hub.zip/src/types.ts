export interface SizeStock {
  size: string;
  stock: number;
}

export interface Product {
  id: string;
  name: string;
  slug: string;
  category: 'Clothing' | 'Shoes' | 'Accessories';
  subcategory: string; // e.g. 'Oversized T-Shirts', 'Air Jordan', etc.
  brand: string; // plain text field, e.g. 'Nike', 'Jordan', 'Adidas'
  price: number;
  discounted_price?: number;
  sizes: SizeStock[];
  colors?: string[];
  images: string[]; // public high-res URLs
  description: string;
  is_featured: boolean;
  status: 'active' | 'out-of-stock' | 'archived';
  created_at: string;
  updated_at: string;
}

export interface CartItem {
  product: Product;
  selectedSize: string;
  quantity: number;
}

export interface Order {
  id: string;
  customerName: string;
  customerPhone: string;
  items: {
    productId: string;
    productName: string;
    brand: string;
    selectedSize: string;
    quantity: number;
    priceAtPurchase: number;
  }[];
  totalPrice: number;
  status: 'pending' | 'completed' | 'cancelled';
  createdAt: string;
}

export interface BlogPost {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  content: string; // Markdown supported
  image: string;
  readTime: string;
  date: string;
}
