import React, { useState, useMemo } from 'react';
import { Product, Order, SizeStock } from '../types';
import { Sparkles, Key, Lock, LogOut, Plus, Edit2, Trash2, Archive, Check, X, ChevronDown, CheckSquare, Square, RefreshCw, Eye, MessageSquare, IndianRupee } from 'lucide-react';

interface AdminViewProps {
  products: Product[];
  orders: Order[];
  onCreateProduct: (p: Product) => void;
  onUpdateProduct: (p: Product) => void;
  onDeleteProduct: (id: string) => void;
  onUpdateStock: (productId: string, sizeName: string, qty: number) => void;
  onBulkOutOfStock: (ids: string[]) => void;
  onBulkArchive: (ids: string[]) => void;
  onUpdateOrderStatus: (orderId: string, status: 'pending' | 'completed' | 'cancelled') => void;
}

export default function AdminView({
  products,
  orders,
  onCreateProduct,
  onUpdateProduct,
  onDeleteProduct,
  onUpdateStock,
  onBulkOutOfStock,
  onBulkArchive,
  onUpdateOrderStatus,
}: AdminViewProps) {
  // Login Gate State
  const [password, setPassword] = useState('');
  const [loggedIn, setLoggedIn] = useState(false);
  const [loginError, setLoginError] = useState('');

  // Active Tab
  const [activeTab, setActiveTab] = useState<'products' | 'inquiries'>('products');

  // Product filters
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  // Bulk selector
  const [selectedProductIds, setSelectedProductIds] = useState<string[]>([]);

  // Create/Edit Form Modal State
  const [showModal, setShowModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  // Form Fields State
  const [formName, setFormName] = useState('');
  const [formBrand, setFormBrand] = useState('');
  const [formCategory, setFormCategory] = useState<'Clothing' | 'Shoes' | 'Accessories'>('Clothing');
  const [formSubcategory, setFormSubcategory] = useState('Oversized T-Shirts');
  const [formPrice, setFormPrice] = useState('');
  const [formDiscountedPrice, setFormDiscountedPrice] = useState('');
  const [formDescription, setFormDescription] = useState('');
  const [formImages, setFormImages] = useState(''); // Comma separated URLs
  const [formColors, setFormColors] = useState(''); // Comma separated
  const [formIsFeatured, setFormIsFeatured] = useState(false);
  const [formSizes, setFormSizes] = useState<SizeStock[]>([
    { size: 'S', stock: 10 },
    { size: 'M', stock: 10 },
    { size: 'L', stock: 10 },
    { size: 'XL', stock: 10 }
  ]);

  // Handle category changes to default appropriate subcategories
  const handleCategoryChange = (cat: 'Clothing' | 'Shoes' | 'Accessories') => {
    setFormCategory(cat);
    if (cat === 'Clothing') {
      setFormSubcategory('Oversized T-Shirts');
      setFormSizes([
        { size: 'S', stock: 10 },
        { size: 'M', stock: 10 },
        { size: 'L', stock: 10 },
        { size: 'XL', stock: 10 }
      ]);
    } else if (cat === 'Shoes') {
      setFormSubcategory('Air Jordan');
      setFormSizes([
        { size: 'UK 7', stock: 5 },
        { size: 'UK 8', stock: 5 },
        { size: 'UK 9', stock: 5 },
        { size: 'UK 10', stock: 5 }
      ]);
    } else {
      setFormSubcategory('Wallets');
      setFormSizes([
        { size: 'One Size', stock: 15 }
      ]);
    }
  };

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === 'admin123') {
      setLoggedIn(true);
      setLoginError('');
    } else {
      setLoginError('Invalid Passcode. Enter the secure owner passcode.');
    }
  };

  // KPI Calculations
  const metrics = useMemo(() => {
    const totalCount = products.filter(p => p.status !== 'archived').length;
    const lowStockCount = products.filter(p => {
      if (p.status === 'archived') return false;
      const totalStock = p.sizes.reduce((sum, s) => sum + s.stock, 0);
      return totalStock <= 5;
    }).length;
    const pendingInquiries = orders.filter(o => o.status === 'pending').length;
    const totalInquiryValue = orders.reduce((sum, o) => o.status !== 'cancelled' ? sum + o.totalPrice : sum, 0);

    return { totalCount, lowStockCount, pendingInquiries, totalInquiryValue };
  }, [products, orders]);

  // Filtered Products
  const filteredProducts = useMemo(() => {
    return products.filter(p => {
      const matchSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          p.brand.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          p.subcategory.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchStatus = statusFilter === 'all' 
        ? p.status !== 'archived' 
        : p.status === statusFilter;

      return matchSearch && matchStatus;
    });
  }, [products, searchQuery, statusFilter]);

  const handleSelectProductToggle = (id: string) => {
    setSelectedProductIds(prev =>
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  };

  const handleSelectAllToggle = () => {
    if (selectedProductIds.length === filteredProducts.length) {
      setSelectedProductIds([]);
    } else {
      setSelectedProductIds(filteredProducts.map(p => p.id));
    }
  };

  const openAddProductModal = () => {
    setEditingProduct(null);
    setFormName('');
    setFormBrand('');
    setFormCategory('Clothing');
    setFormSubcategory('Oversized T-Shirts');
    setFormPrice('');
    setFormDiscountedPrice('');
    setFormDescription('');
    setFormImages('');
    setFormColors('');
    setFormIsFeatured(false);
    setFormSizes([
      { size: 'S', stock: 10 },
      { size: 'M', stock: 10 },
      { size: 'L', stock: 10 },
      { size: 'XL', stock: 10 }
    ]);
    setShowModal(true);
  };

  const openEditProductModal = (product: Product) => {
    setEditingProduct(product);
    setFormName(product.name);
    setFormBrand(product.brand);
    setFormCategory(product.category);
    setFormSubcategory(product.subcategory);
    setFormPrice(product.price.toString());
    setFormDiscountedPrice(product.discounted_price ? product.discounted_price.toString() : '');
    setFormDescription(product.description);
    setFormImages(product.images.join(', '));
    setFormColors(product.colors ? product.colors.join(', ') : '');
    setFormIsFeatured(product.is_featured);
    setFormSizes([...product.sizes]);
    setShowModal(true);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName || !formBrand || !formPrice || !formDescription || !formImages) {
      alert("Please fill out all mandatory fields.");
      return;
    }

    const priceNum = parseFloat(formPrice);
    const discPriceNum = formDiscountedPrice ? parseFloat(formDiscountedPrice) : undefined;

    // Handle standard URL splits
    const imagesArr = formImages.split(',').map(u => u.trim()).filter(Boolean);
    const colorsArr = formColors ? formColors.split(',').map(c => c.trim()).filter(Boolean) : undefined;

    // Auto-generate Slug
    const slug = formName.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)+/g, '');

    if (editingProduct) {
      const updated: Product = {
        ...editingProduct,
        name: formName,
        brand: formBrand,
        category: formCategory,
        subcategory: formSubcategory,
        price: priceNum,
        discounted_price: discPriceNum,
        description: formDescription,
        images: imagesArr,
        colors: colorsArr,
        sizes: formSizes,
        is_featured: formIsFeatured,
        updated_at: new Date().toISOString()
      };
      onUpdateProduct(updated);
    } else {
      const created: Product = {
        id: 'prod-' + Math.random().toString(36).substr(2, 9),
        name: formName,
        slug: slug,
        category: formCategory,
        subcategory: formSubcategory,
        brand: formBrand,
        price: priceNum,
        discounted_price: discPriceNum,
        sizes: formSizes,
        colors: colorsArr,
        images: imagesArr,
        description: formDescription,
        is_featured: formIsFeatured,
        status: 'active',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };
      onCreateProduct(created);
    }

    setShowModal(false);
  };

  const handleStockFormChange = (idx: number, field: 'stock' | 'size', value: string) => {
    const updated = [...formSizes];
    if (field === 'stock') {
      updated[idx].stock = Math.max(0, parseInt(value) || 0);
    } else {
      updated[idx].size = value;
    }
    setFormSizes(updated);
  };

  const addSizeToForm = () => {
    setFormSizes([...formSizes, { size: '', stock: 5 }]);
  };

  const removeSizeFromForm = (idx: number) => {
    setFormSizes(formSizes.filter((_, i) => i !== idx));
  };

  // Gated Login Render
  if (!loggedIn) {
    return (
      <div className="min-h-[70vh] flex items-center justify-center p-4" id="admin-login-view">
        <div className="bg-stone-900 text-white rounded-none border border-stone-800 shadow-none p-8 w-full max-w-md animate-fade-in">
          <div className="text-center mb-8 select-none">
            <span className="inline-flex items-center justify-center w-12 h-12 rounded-none bg-[#ece8e1] mb-4 text-stone-900 text-xl">
              <Lock size={20} />
            </span>
            <h1 className="font-serif italic text-xl text-stone-100">The Branded Hub</h1>
            <p className="text-[9px] text-stone-400 uppercase tracking-widest font-mono mt-1">BACKSTAGE OFFICE GATE</p>
          </div>

          <form onSubmit={handleLoginSubmit} className="space-y-5">
            {loginError && (
              <div className="bg-stone-800 border border-stone-700 text-stone-300 text-xs px-3 py-2.5 rounded-none font-sans">
                ⚠️ {loginError}
              </div>
            )}

            <div>
              <label className="block text-[9px] font-bold text-stone-400 uppercase tracking-widest mb-1.5 font-mono">Owner Passcode</label>
              <div className="relative">
                <input 
                  type="password"
                  placeholder="••••••••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-stone-950 border border-stone-800 rounded-none px-4 py-3 pl-10 text-sm text-white focus:outline-none focus:border-stone-500 font-mono"
                  required
                />
                <Key className="absolute left-3.5 top-1/2 -translate-y-1/2 text-stone-500" size={16} />
              </div>
              <p className="text-[10px] text-stone-500 mt-2 font-sans italic">Enter the default testing passcode: <strong className="text-stone-300">admin123</strong></p>
            </div>

            <button
              type="submit"
              className="w-full bg-stone-100 hover:bg-[#ece8e1] text-stone-900 text-xs font-bold uppercase tracking-widest py-3.5 rounded-none transition-colors"
            >
              Sign In to Dashboard
            </button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-12 animate-fade-in" id="admin-dashboard-view">
      {/* Title Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-stone-200 pb-5 mb-8 gap-4">
        <div>
          <span className="text-[10px] font-mono text-stone-500 font-bold tracking-widest uppercase block mb-1">👑 PRIVATE OFFICE</span>
          <h1 className="font-serif italic text-2xl text-stone-950 leading-none">
            Hub Overseer Dashboard
          </h1>
        </div>
        <button
          onClick={() => setLoggedIn(false)}
          className="flex items-center gap-1.5 border border-stone-200 hover:border-black text-stone-700 text-xs font-bold uppercase tracking-widest px-4 py-2 rounded-none self-start md:self-auto font-mono"
        >
          <LogOut size={14} /> Exit Admin
        </button>
      </div>

      {/* KPI Widgets Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 mb-8">
        <div className="bg-white border border-stone-200 rounded-none p-4 sm:p-5 shadow-none">
          <span className="text-[9px] font-bold text-stone-400 uppercase tracking-wider block mb-1">TOTAL PRODUCTS</span>
          <span className="text-xl sm:text-2xl font-black text-stone-950 font-mono">{metrics.totalCount}</span>
          <p className="text-[9px] text-stone-400 mt-1 uppercase tracking-tight">Active or Out-of-Stock drops</p>
        </div>
        
        <div className="bg-white border border-stone-200 rounded-none p-4 sm:p-5 shadow-none">
          <span className="text-[9px] font-bold text-stone-800 uppercase tracking-wider block mb-1">LOW STOCK ALERTS</span>
          <span className="text-xl sm:text-2xl font-black text-stone-900 font-mono">{metrics.lowStockCount}</span>
          <p className="text-[9px] text-stone-400 mt-1 uppercase tracking-tight">Under 5 total items remaining</p>
        </div>

        <div className="bg-white border border-stone-200 rounded-none p-4 sm:p-5 shadow-none">
          <span className="text-[9px] font-bold text-stone-600 uppercase tracking-wider block mb-1">PENDING INQUIRIES</span>
          <span className="text-xl sm:text-2xl font-black text-stone-800 font-mono">{metrics.pendingInquiries}</span>
          <p className="text-[9px] text-stone-400 mt-1 uppercase tracking-tight">WhatsApp checkouts queued</p>
        </div>

        <div className="bg-white border border-stone-200 rounded-none p-4 sm:p-5 shadow-none">
          <span className="text-[9px] font-bold text-stone-700 uppercase tracking-wider block mb-1">ESTIMATED PIPELINE</span>
          <span className="text-xl sm:text-2xl font-black text-stone-900 font-mono">₹{metrics.totalInquiryValue.toLocaleString('en-IN')}</span>
          <p className="text-[9px] text-stone-400 mt-1 uppercase tracking-tight">Value of logged WhatsApp carts</p>
        </div>
      </div>

      {/* Primary Navigation Tabs */}
      <div className="flex border-b border-stone-200 mb-6">
        <button
          onClick={() => setActiveTab('products')}
          className={`py-3 px-6 text-xs font-bold uppercase tracking-widest border-b-2 transition-all font-mono flex items-center gap-2 ${
            activeTab === 'products' ? 'border-black text-black font-extrabold' : 'border-transparent text-stone-400 hover:text-stone-950'
          }`}
        >
          📦 Catalog Inventory ({products.filter(p=>p.status !== 'archived').length})
        </button>
        <button
          onClick={() => setActiveTab('inquiries')}
          className={`py-3 px-6 text-xs font-bold uppercase tracking-widest border-b-2 transition-all font-mono flex items-center gap-2 ${
            activeTab === 'inquiries' ? 'border-black text-black font-extrabold' : 'border-transparent text-stone-400 hover:text-zinc-950'
          }`}
        >
          💬 WhatsApp Inquiry Ledgers ({orders.length})
        </button>
      </div>

      {/* Tab 1: Catalog Inventory Management */}
      {activeTab === 'products' && (
        <div className="space-y-6">
          {/* Filtering row */}
          <div className="flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center">
            <div className="flex flex-wrap gap-2 items-center w-full sm:w-auto shrink-0 select-none">
              {/* Search */}
              <input 
                type="text"
                placeholder="Search catalog products..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-white border border-zinc-200 rounded-none px-3 py-2 text-xs font-semibold focus:outline-none focus:border-zinc-500 w-full sm:w-48 font-sans"
              />

              {/* Status Select */}
              <div className="relative">
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="appearance-none bg-white border border-zinc-200 rounded-none px-3.5 py-2 pr-8 text-xs font-semibold uppercase tracking-widest text-zinc-700 cursor-pointer focus:outline-none"
                >
                  <option value="all">📦 All Active Drops</option>
                  <option value="active">✓ Active Only</option>
                  <option value="out-of-stock">⚠️ Out of Stock Only</option>
                </select>
                <ChevronDown size={14} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-zinc-500 pointer-events-none" />
              </div>
            </div>

            <button
              onClick={openAddProductModal}
              className="w-full sm:w-auto bg-zinc-950 hover:bg-black text-white text-xs font-bold uppercase tracking-widest px-4 py-3 rounded-none flex items-center justify-center gap-1.5 shadow-none"
              id="admin-add-product"
            >
              <Plus size={16} /> Add New Drip
            </button>
          </div>

          {/* Bulk Operations Drawer */}
          {selectedProductIds.length > 0 && (
            <div className="bg-zinc-950 text-white rounded-none p-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 animate-slide-up">
              <span className="text-xs font-mono font-semibold uppercase tracking-widest">
                Selected {selectedProductIds.length} Products
              </span>
              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => {
                    onBulkOutOfStock(selectedProductIds);
                    setSelectedProductIds([]);
                  }}
                  className="bg-amber-500 hover:bg-amber-600 text-black text-[10px] font-bold uppercase tracking-wider px-3.5 py-2 rounded-none"
                >
                  Mark Out-Of-Stock
                </button>
                <button
                  onClick={() => {
                    onBulkArchive(selectedProductIds);
                    setSelectedProductIds([]);
                  }}
                  className="bg-red-600 hover:bg-red-700 text-white text-[10px] font-bold uppercase tracking-wider px-3.5 py-2 rounded-none"
                >
                  Archive Selected
                </button>
                <button
                  onClick={() => setSelectedProductIds([])}
                  className="bg-zinc-900 hover:bg-zinc-800 text-zinc-300 text-[10px] font-bold uppercase tracking-wider px-3 py-2 rounded-none"
                >
                  Cancel
                </button>
              </div>
            </div>
          )}

          {/* Table list */}
          <div className="bg-white border border-zinc-200 rounded-none overflow-x-auto shadow-none">
            <table className="w-full text-left border-collapse min-w-[700px]">
              <thead className="bg-zinc-50 border-b border-zinc-200">
                <tr className="text-[10px] font-mono font-bold text-zinc-400 uppercase tracking-widest">
                  <th className="py-3.5 px-4 w-10 text-center select-none">
                    <button onClick={handleSelectAllToggle} className="p-1 text-zinc-500 hover:bg-zinc-100 rounded-none">
                      {selectedProductIds.length === filteredProducts.length ? <CheckSquare size={16} /> : <Square size={16} />}
                    </button>
                  </th>
                  <th className="py-3.5 px-4">Drip Image / Item Name</th>
                  <th className="py-3.5 px-4">Brand / Segment</th>
                  <th className="py-3.5 px-4">Price / Promo</th>
                  <th className="py-3.5 px-4 w-60">Size-by-Size Stock Level Adjustments</th>
                  <th className="py-3.5 px-4 text-center">Status</th>
                  <th className="py-3.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-200 text-xs font-sans">
                {filteredProducts.map(p => {
                  const totalStock = p.sizes.reduce((sum, s) => sum + s.stock, 0);
                  const isChecked = selectedProductIds.includes(p.id);

                  return (
                    <tr key={p.id} className={`hover:bg-zinc-50/50 transition-colors ${totalStock === 0 ? 'bg-amber-50/20' : ''}`}>
                      {/* Checkbox */}
                      <td className="py-4 px-4 text-center select-none">
                        <button onClick={() => handleSelectProductToggle(p.id)} className="text-zinc-400 hover:text-zinc-800">
                          {isChecked ? <CheckSquare size={16} className="text-stone-900" /> : <Square size={16} />}
                        </button>
                      </td>

                      {/* Product Name & Image */}
                      <td className="py-4 px-4">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-12 bg-zinc-50 border border-zinc-200 rounded-none overflow-hidden shrink-0">
                            <img src={p.images[0]} alt={p.name} className="w-full h-full object-cover" />
                          </div>
                          <div>
                            <span className="text-[9px] font-bold text-zinc-400 tracking-widest uppercase block">{p.subcategory}</span>
                            <span className="font-extrabold text-zinc-950 uppercase block line-clamp-1">{p.name}</span>
                            <span className="text-[10px] text-zinc-400 block font-mono">ID: {p.id}</span>
                          </div>
                        </div>
                      </td>

                      {/* Brand */}
                      <td className="py-4 px-4 font-bold text-zinc-800 uppercase tracking-wide">
                        {p.brand}
                      </td>

                      {/* Price */}
                      <td className="py-4 px-4">
                        <div className="font-mono font-bold text-zinc-950 flex flex-col">
                          {p.discounted_price ? (
                            <>
                              <span className="text-stone-900">₹{p.discounted_price.toLocaleString('en-IN')}</span>
                              <span className="text-[10px] text-zinc-400 line-through">₹{p.price.toLocaleString('en-IN')}</span>
                            </>
                          ) : (
                            <span>₹{p.price.toLocaleString('en-IN')}</span>
                          )}
                        </div>
                      </td>

                      {/* Inline Stock level adjustment */}
                      <td className="py-4 px-4 select-none">
                        <div className="grid grid-cols-2 gap-x-3 gap-y-1.5 font-mono">
                          {p.sizes.map(sz => (
                            <div key={sz.size} className="flex items-center justify-between border border-zinc-100 rounded-none px-1.5 py-0.5 bg-zinc-50">
                              <span className="text-[10px] font-bold text-zinc-400 uppercase">{sz.size}:</span>
                              <div className="flex items-center gap-1">
                                <button
                                  onClick={() => onUpdateStock(p.id, sz.size, sz.stock - 1)}
                                  className="w-4 h-4 bg-white hover:bg-zinc-100 border border-zinc-200 rounded-none text-[9px] font-bold text-center leading-none"
                                >
                                  -
                                </button>
                                <span className={`text-[10px] font-bold w-4 text-center ${sz.stock === 0 ? 'text-red-600 font-extrabold' : 'text-zinc-800'}`}>{sz.stock}</span>
                                <button
                                  onClick={() => onUpdateStock(p.id, sz.size, sz.stock + 1)}
                                  className="w-4 h-4 bg-white hover:bg-zinc-100 border border-zinc-200 rounded-none text-[9px] font-bold text-center leading-none"
                                >
                                  +
                                </button>
                              </div>
                            </div>
                          ))}
                        </div>
                      </td>

                      {/* Status */}
                      <td className="py-4 px-4 text-center">
                        <span className={`inline-block text-[9px] font-mono font-bold px-2 py-0.5 rounded-none border uppercase tracking-widest ${
                          totalStock === 0 || p.status === 'out-of-stock'
                            ? 'bg-red-50 border-red-100 text-red-600'
                            : 'bg-green-50 border-green-100 text-green-600'
                        }`}>
                          {totalStock === 0 ? 'SOLDOUT' : p.status}
                        </span>
                      </td>

                      {/* Actions */}
                      <td className="py-4 px-4 text-right">
                        <div className="flex justify-end gap-2 shrink-0">
                          <button
                            onClick={() => openEditProductModal(p)}
                            className="p-1.5 bg-white hover:bg-zinc-50 border border-zinc-200 rounded-none text-zinc-700"
                            title="Edit product"
                          >
                            <Edit2 size={13} />
                          </button>
                          <button
                            onClick={() => {
                              if (confirm("Are you sure you want to delete this listing?")) {
                                onDeleteProduct(p.id);
                              }
                            }}
                            className="p-1.5 bg-white hover:bg-red-50 border border-zinc-200 hover:border-red-300 rounded-none text-red-600"
                            title="Delete listing"
                          >
                            <Trash2 size={13} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 2: WhatsApp Inquiry Logs Ledger */}
      {activeTab === 'inquiries' && (
        <div className="space-y-6 animate-fade-in">
          {orders.length === 0 ? (
            <div className="bg-white border border-zinc-200 rounded-none p-16 text-center max-w-lg mx-auto shadow-none">
              <span className="text-3xl block mb-3">💬</span>
              <h2 className="font-display text-xs font-bold uppercase tracking-widest text-zinc-950 mb-1">No inquiries registered yet</h2>
              <p className="text-zinc-400 text-xs leading-relaxed mb-4 font-light">
                When an online user clicks "Buy on WhatsApp" on any Product Detail Page, their inquiry details are automatically tracked and listed here for your backoffice review.
              </p>
            </div>
          ) : (
            <div className="bg-white border border-zinc-200 rounded-none overflow-hidden shadow-none">
              <table className="w-full text-left border-collapse min-w-[700px]">
                <thead className="bg-zinc-50 border-b border-zinc-200">
                  <tr className="text-[10px] font-mono font-bold text-zinc-400 uppercase tracking-widest">
                    <th className="py-3 px-4">Inquiry / Date</th>
                    <th className="py-3 px-4">Customer Details</th>
                    <th className="py-3 px-4">Requested Streetwear Drop Item</th>
                    <th className="py-3 px-4 font-mono">Subtotal Value</th>
                    <th className="py-3 px-4 text-center">Status</th>
                    <th className="py-3 px-4 text-right">Negotiation Link</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-200 text-xs font-sans">
                  {orders.map(order => (
                    <tr key={order.id} className="hover:bg-zinc-50/50 transition-colors">
                      {/* ID and Date */}
                      <td className="py-4 px-4 font-mono">
                        <span className="font-bold text-zinc-950 uppercase block">{order.id}</span>
                        <span className="text-[10px] text-zinc-400 block mt-0.5">{new Date(order.createdAt).toLocaleDateString('en-IN', {
                          day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit'
                        })}</span>
                      </td>

                      {/* Customer Name / Phone */}
                      <td className="py-4 px-4 font-bold text-zinc-800">
                        <span className="uppercase block text-zinc-950 font-black tracking-wide">{order.customerName}</span>
                        <a href={`tel:${order.customerPhone}`} className="text-zinc-500 font-mono tracking-wider hover:underline">{order.customerPhone}</a>
                      </td>

                      {/* Items requested */}
                      <td className="py-4 px-4 leading-relaxed">
                        {order.items.map((item, itemIdx) => (
                          <div key={itemIdx} className="mb-1 text-xs">
                            <span className="text-zinc-400 font-mono text-[9px] font-bold uppercase tracking-wider">{item.brand}:</span>{' '}
                            <span className="font-extrabold uppercase text-zinc-900">{item.productName}</span>{' '}
                            <span className="bg-zinc-950 text-white font-mono text-[9px] font-bold px-1.5 py-0.5 rounded-none">{item.selectedSize}</span>{' '}
                            <span className="text-zinc-500 font-bold font-mono">x{item.quantity}</span>
                          </div>
                        ))}
                      </td>

                      {/* Total Value */}
                      <td className="py-4 px-4 font-mono font-bold text-zinc-950">
                        ₹{order.totalPrice.toLocaleString('en-IN')}
                      </td>

                      {/* Status */}
                      <td className="py-4 px-4 text-center select-none">
                        <div className="relative inline-block text-left">
                          <select
                            value={order.status}
                            onChange={(e) => onUpdateOrderStatus(order.id, e.target.value as any)}
                            className={`appearance-none font-mono text-[9px] font-bold px-3 py-1 rounded-none uppercase tracking-widest text-center cursor-pointer focus:outline-none border ${
                              order.status === 'pending'
                                ? 'bg-amber-50 border-amber-200 text-amber-600'
                                : order.status === 'completed'
                                ? 'bg-green-50 border-green-200 text-green-600'
                                : 'bg-zinc-100 border-zinc-200 text-zinc-400'
                            }`}
                          >
                            <option value="pending">⏳ Pending</option>
                            <option value="completed">✓ Shipped</option>
                            <option value="cancelled">❌ Cancelled</option>
                          </select>
                        </div>
                      </td>

                      {/* Direct WhatsApp chat action */}
                      <td className="py-4 px-4 text-right">
                        <a
                          href={`https://wa.me/${order.customerPhone.replace(/\D/g, '')}?text=${encodeURIComponent(
                            `Hello ${order.customerName}! I'm the owner of The Branded Hub Bangalore. Regarding your recent checkout inquiry on our website...`
                          )}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1.5 bg-black hover:bg-stone-850 text-white text-[10px] font-bold uppercase tracking-widest px-3.5 py-2.5 rounded-none shadow-none"
                        >
                          <MessageSquare size={12} /> Contact Customer
                        </a>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Product Creator/Editor Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          {/* Backdrop */}
          <div className="absolute inset-0 bg-zinc-950/80 transition-opacity" onClick={() => setShowModal(false)} />

          <div className="relative bg-white border border-zinc-200 rounded-none shadow-none p-6 sm:p-8 w-full max-w-2xl max-h-[90vh] overflow-y-auto z-10 animate-fade-in animate-duration-200">
            {/* Header */}
            <div className="flex items-center justify-between pb-4 border-b border-zinc-200 mb-6">
              <h3 className="font-display text-sm font-black uppercase text-zinc-950 tracking-widest flex items-center gap-1.5">
                <Sparkles className="text-stone-800" size={16} /> {editingProduct ? 'EDIT DROP DETAILS' : 'CREATE NEW STREETWEAR DROP'}
              </h3>
              <button onClick={() => setShowModal(false)} className="p-1 text-zinc-700 hover:bg-zinc-100 rounded-none">
                <X size={18} />
              </button>
            </div>

            {/* Form */}
            <form onSubmit={handleFormSubmit} className="space-y-4 font-sans text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Name */}
                <div>
                  <label className="block text-[9px] font-bold text-zinc-400 uppercase tracking-widest mb-1 font-mono">Product Title *</label>
                  <input
                    type="text"
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    placeholder="e.g. Nike Air Jordan 1 Retro High"
                    className="w-full border border-zinc-200 rounded-none px-3 py-2 focus:outline-none focus:border-stone-800 uppercase font-semibold text-zinc-900"
                    required
                  />
                </div>

                {/* Brand */}
                <div>
                  <label className="block text-[9px] font-bold text-zinc-400 uppercase tracking-widest mb-1 font-mono">Brand name (Plain Text) *</label>
                  <input
                    type="text"
                    value={formBrand}
                    onChange={(e) => setFormBrand(e.target.value)}
                    placeholder="e.g. Nike, Jordan, Adidas, The Branded Hub"
                    className="w-full border border-zinc-200 rounded-none px-3 py-2 focus:outline-none focus:border-stone-800 font-semibold"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Category selection */}
                <div>
                  <label className="block text-[9px] font-bold text-zinc-400 uppercase tracking-widest mb-1 font-mono">Main Category Segment *</label>
                  <div className="relative">
                    <select
                      value={formCategory}
                      onChange={(e) => handleCategoryChange(e.target.value as any)}
                      className="w-full appearance-none bg-white border border-zinc-200 rounded-none px-3.5 py-2 pr-8 font-semibold uppercase text-zinc-800 focus:outline-none"
                    >
                      <option value="Clothing">Clothing</option>
                      <option value="Shoes">Shoes</option>
                      <option value="Accessories">Accessories</option>
                    </select>
                    <ChevronDown size={14} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-zinc-500 pointer-events-none" />
                  </div>
                </div>

                {/* Subcategory selection */}
                <div>
                  <label className="block text-[9px] font-bold text-zinc-400 uppercase tracking-widest mb-1 font-mono">Sub-category Label *</label>
                  <div className="relative">
                    <select
                      value={formSubcategory}
                      onChange={(e) => setFormSubcategory(e.target.value)}
                      className="w-full appearance-none bg-white border border-zinc-200 rounded-none px-3.5 py-2 pr-8 font-semibold uppercase text-zinc-800 focus:outline-none"
                    >
                      {formCategory === 'Clothing' ? (
                        <>
                          <option value="Shirts">Shirts</option>
                          <option value="T-Shirts">T-Shirts</option>
                          <option value="Oversized T-Shirts">Oversized T-Shirts</option>
                          <option value="Hoodies">Hoodies</option>
                          <option value="Pants">Pants</option>
                        </>
                      ) : formCategory === 'Shoes' ? (
                        <>
                          <option value="Air Jordan">Air Jordan</option>
                          <option value="Sport Shoes">Sport Shoes</option>
                          <option value="Formal Shoes">Formal Shoes</option>
                        </>
                      ) : (
                        <>
                          <option value="Wallets">Wallets</option>
                          <option value="Belts">Belts</option>
                          <option value="Hats">Hats</option>
                        </>
                      )}
                    </select>
                    <ChevronDown size={14} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-zinc-500 pointer-events-none" />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Price */}
                <div>
                  <label className="block text-[9px] font-bold text-zinc-400 uppercase tracking-widest mb-1 font-mono">Retail Price (INR) *</label>
                  <input
                    type="number"
                    value={formPrice}
                    onChange={(e) => setFormPrice(e.target.value)}
                    placeholder="e.g. 16995"
                    className="w-full border border-zinc-200 rounded-none px-3 py-2 focus:outline-none focus:border-stone-800 font-mono"
                    required
                  />
                </div>

                {/* Discount price */}
                <div>
                  <label className="block text-[9px] font-bold text-zinc-400 uppercase tracking-widest mb-1 font-mono">Promo Discounted Price (INR - Optional)</label>
                  <input
                    type="number"
                    value={formDiscountedPrice}
                    onChange={(e) => setFormDiscountedPrice(e.target.value)}
                    placeholder="e.g. 14995"
                    className="w-full border border-zinc-200 rounded-none px-3 py-2 focus:outline-none focus:border-stone-800 font-mono"
                  />
                </div>
              </div>

              {/* Description */}
              <div>
                <label className="block text-[9px] font-bold text-zinc-400 uppercase tracking-widest mb-1 font-mono">Description / Story Details *</label>
                <textarea
                  value={formDescription}
                  onChange={(e) => setFormDescription(e.target.value)}
                  placeholder="Detail fabric heavy GSM parameters, sneaker origin story, or styling recommendations..."
                  rows={3}
                  className="w-full border border-zinc-200 rounded-none px-3 py-2 focus:outline-none focus:border-stone-800 font-sans"
                  required
                />
              </div>

              {/* Images */}
              <div>
                <label className="block text-[9px] font-bold text-zinc-400 uppercase tracking-widest mb-1 font-mono">High-Res Image URLs * (Comma-separated)</label>
                <input
                  type="text"
                  value={formImages}
                  onChange={(e) => setFormImages(e.target.value)}
                  placeholder="e.g. https://images.unsplash.com/photo-1..., https://images.unsplash.com/photo-2..."
                  className="w-full border border-zinc-200 rounded-none px-3 py-2 focus:outline-none focus:border-stone-800 font-mono text-[10px]"
                  required
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Colors */}
                <div>
                  <label className="block text-[9px] font-bold text-zinc-400 uppercase tracking-widest mb-1 font-mono">Color Swatches (Comma-separated)</label>
                  <input
                    type="text"
                    value={formColors}
                    onChange={(e) => setFormColors(e.target.value)}
                    placeholder="e.g. Vintage Black, White, Retro Red"
                    className="w-full border border-zinc-200 rounded-none px-3 py-2 focus:outline-none focus:border-stone-800 font-sans"
                  />
                </div>

                {/* Is featured */}
                <div className="flex items-center gap-2 pt-6 select-none">
                  <input
                    type="checkbox"
                    checked={formIsFeatured}
                    onChange={(e) => setFormIsFeatured(e.target.checked)}
                    id="form-is-featured"
                    className="rounded-none border-zinc-350 text-stone-900 focus:ring-stone-800"
                  />
                  <label htmlFor="form-is-featured" className="text-xs font-semibold text-zinc-700 cursor-pointer">
                    Display as Featured on Homepage Drop
                  </label>
                </div>
              </div>

              {/* Sizes and stock configuration */}
              <div className="border-t border-zinc-200 pt-4">
                <div className="flex justify-between items-center mb-3">
                  <h4 className="text-[9px] font-mono font-bold text-zinc-400 uppercase tracking-widest">Sizes & Quantity Stocks</h4>
                  <button
                    type="button"
                    onClick={addSizeToForm}
                    className="text-[9px] font-mono font-bold text-stone-800 hover:underline flex items-center gap-1 uppercase tracking-wider"
                  >
                    + Add Size Row
                  </button>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {formSizes.map((sz, idx) => (
                    <div key={idx} className="flex items-center gap-2 border border-zinc-200 p-2 rounded-none bg-zinc-50 relative">
                      <input
                        type="text"
                        value={sz.size}
                        onChange={(e) => handleStockFormChange(idx, 'size', e.target.value)}
                        placeholder="Size (e.g. UK 8)"
                        className="w-20 bg-white border border-zinc-200 rounded-none px-1.5 py-1 text-center font-mono font-bold text-xs uppercase"
                        required
                      />
                      <input
                        type="number"
                        value={sz.stock}
                        onChange={(e) => handleStockFormChange(idx, 'stock', e.target.value)}
                        className="w-16 bg-white border border-zinc-200 rounded-none px-1.5 py-1 text-center font-mono font-bold text-xs"
                        required
                      />
                      <button
                        type="button"
                        onClick={() => removeSizeFromForm(idx)}
                        className="p-1 hover:bg-stone-100 rounded-none text-stone-800 absolute right-1 top-1/2 -translate-y-1/2"
                        title="Delete row"
                      >
                        <Trash2 size={12} />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Form submit actions */}
              <div className="flex gap-3 pt-6 border-t border-zinc-200">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="flex-1 border border-zinc-200 hover:bg-zinc-50 text-zinc-700 text-xs font-bold uppercase tracking-widest py-3.5 rounded-none font-mono"
                >
                  Discard Changes
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-zinc-950 hover:bg-black text-white text-xs font-bold uppercase tracking-widest py-3.5 rounded-none font-mono shadow-none"
                >
                  Save Drop
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
