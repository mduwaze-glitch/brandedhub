import React, { useState, useMemo } from 'react';
import { CartItem, Product } from '../types';
import { X, Plus, Minus, MessageSquare, ShoppingBag, Sparkles, AlertCircle, Award } from 'lucide-react';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  onUpdateQty: (productId: string, size: string, qty: number) => void;
  onRemoveItem: (productId: string, size: string) => void;
  onCheckout: (customerName: string, customerPhone: string) => void;
}

export default function CartDrawer({
  isOpen,
  onClose,
  cart,
  onUpdateQty,
  onRemoveItem,
  onCheckout,
}: CartDrawerProps) {
  const [showPrompt, setShowPrompt] = useState(false);
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [formError, setFormError] = useState('');

  // Total items inside the bag
  const totalItemCount = useMemo(() => {
    return cart.reduce((sum, item) => sum + item.quantity, 0);
  }, [cart]);

  // Base Subtotal before multi-buy discounts
  const baseSubtotal = useMemo(() => {
    return cart.reduce((sum, item) => {
      const activePrice = item.product.discounted_price || item.product.price;
      return sum + (activePrice * item.quantity);
    }, 0);
  }, [cart]);

  // Modern multi-buy automatic discounts:
  // 2 items: Extra 10% Off
  // 4+ items: Extra 20% Off
  const automaticDiscount = useMemo(() => {
    if (totalItemCount >= 4) {
      return Math.round(baseSubtotal * 0.20);
    } else if (totalItemCount >= 2) {
      return Math.round(baseSubtotal * 0.10);
    }
    return 0;
  }, [totalItemCount, baseSubtotal]);

  const cartSubtotal = baseSubtotal - automaticDiscount;

  // Shipping threshold (free shipping on orders above ₹1,999)
  const shippingCharge = cartSubtotal >= 1999 ? 0 : 150;
  const grandTotal = cartSubtotal + shippingCharge;

  // Super Drip Points earned
  const earnedPoints = Math.round(cartSubtotal / 10);

  const handleCheckoutInitiate = () => {
    if (cart.length === 0) return;
    setShowPrompt(true);
  };

  const handleWhatsAppCheckoutSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName || !customerPhone) {
      setFormError("Contact Name and Phone are required.");
      return;
    }
    if (customerPhone.length < 10) {
      setFormError("Please enter a valid 10-digit mobile number.");
      return;
    }

    setFormError('');
    setShowPrompt(false);

    // 1. Signal parent app to log these inquiries in Admin Panel!
    onCheckout(customerName, customerPhone);

    // 2. Generate WhatsApp deep link for the entire Cart list
    let itemDetailsText = '';
    cart.forEach((item, index) => {
      const activePrice = item.product.discounted_price || item.product.price;
      itemDetailsText += `${index + 1}. *${item.product.brand}* - ${item.product.name}\n`;
      itemDetailsText += `   Size: ${item.selectedSize} | Qty: ${item.quantity}\n`;
      itemDetailsText += `   Price: ₹${activePrice.toLocaleString('en-IN')}${item.quantity > 1 ? ` each (Sub: ₹${(activePrice * item.quantity).toLocaleString('en-IN')})` : ''}\n\n`;
    });

    const currentUrl = window.location.origin;

    const message = `Hello The Branded Hub Bangalore! 🏬🛍️
    
I would like to order my Shopping Bag items:

${itemDetailsText}*Original Basket Price:* ₹${baseSubtotal.toLocaleString('en-IN')}
*Multi-buy discount applied:* -₹${automaticDiscount.toLocaleString('en-IN')}
*Special Promo Subtotal:* ₹${cartSubtotal.toLocaleString('en-IN')}
*Courier Shipping Fee:* ${shippingCharge === 0 ? 'FREE DELIVERY' : `₹${shippingCharge}`}
*Estimated Total:* ₹${grandTotal.toLocaleString('en-IN')}
*Super Drip Points Earned:* ${earnedPoints} pts

*My Contact Info:*
- Name: ${customerName}
- Phone: ${customerPhone}

*Checkout From:* ${currentUrl}

Please process my booking and send me payment details. Thank you!`;

    // Redirect
    const waUrl = `https://wa.me/9187718184915?text=${encodeURIComponent(message)}`;
    window.open(waUrl, '_blank');
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end select-none" id="cart-drawer">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/40 transition-opacity"
        onClick={onClose}
      />

      {/* Cart Container */}
      <div className="relative w-full max-w-md h-full bg-[#fafaf9] shadow-2xl flex flex-col animate-slide-left z-10 text-[#111111]">
        
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-stone-200 bg-white">
          <div className="flex items-center gap-2">
            <ShoppingBag size={15} className="text-stone-800" />
            <h2 className="font-sans text-[10px] font-extrabold uppercase tracking-widest">
              SHOPPING BAG ({totalItemCount} ITEMS)
            </h2>
          </div>
          <button 
            onClick={onClose}
            className="p-1 text-stone-600 hover:text-stone-900"
          >
            <X size={18} />
          </button>
        </div>

        {/* Dynamic Shipping Progress Alert */}
        {cart.length > 0 && (
          <div className="bg-[#ece8e1] text-stone-900 text-center py-2 px-4 text-[9px] font-bold tracking-widest uppercase shrink-0 border-b border-stone-200">
            {cartSubtotal >= 1999 ? (
              <span className="text-stone-800 font-extrabold">✓ COMPLIMENTARY COURIER DELIVERY SECURED!</span>
            ) : (
              <span>Add <strong className="text-stone-900 font-extrabold">₹{(1999 - cartSubtotal).toLocaleString('en-IN')}</strong> more for complimentary delivery!</span>
            )}
          </div>
        )}

        {/* Dynamic Loyalty Reward progress */}
        {cart.length > 0 && (
          <div className="bg-white border-b border-stone-200 px-5 py-3 text-[11px] shrink-0">
            <div className="flex justify-between items-center mb-1 text-stone-800 font-bold uppercase tracking-wide">
              <span className="flex items-center gap-1"><Award size={13} className="text-stone-600" /> REWARDS STATUS</span>
              <span className="text-[10px] text-stone-500">{totalItemCount >= 4 ? 'MEGA 20% OFF' : totalItemCount >= 2 ? 'BUNDLE 10% OFF' : 'ADD 1 MORE FOR 10% OFF'}</span>
            </div>
            <div className="w-full bg-stone-100 h-1.5 mt-2">
              <div 
                className="bg-black h-1.5 transition-all duration-350"
                style={{ width: `${Math.min(100, (totalItemCount / 4) * 100)}%` }}
              />
            </div>
          </div>
        )}

        {/* Scrollable list */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4 bg-[#fafaf9]">
          {cart.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center px-4 py-20">
              <span className="text-3xl block mb-4">🛒</span>
              <h3 className="font-serif italic text-sm text-stone-850 mb-1">Your bag is empty</h3>
              <p className="text-stone-500 text-[11px] leading-relaxed max-w-xs mb-6">
                Curate your streetwear collection by selecting your premium drop items and sizes.
              </p>
              <button
                onClick={onClose}
                className="bg-black text-white text-[10px] font-bold uppercase tracking-widest px-6 py-3.5"
              >
                Continue Curating
              </button>
            </div>
          ) : (
            cart.map(item => {
              const activePrice = item.product.discounted_price || item.product.price;
              return (
                <div 
                  key={`${item.product.id}-${item.selectedSize}`}
                  className="flex gap-4 border border-stone-200 p-3 bg-white hover:border-stone-400 transition-colors relative"
                >
                  <div className="w-16 h-20 bg-stone-50 border border-stone-200 overflow-hidden shrink-0">
                    <img src={item.product.images[0]} alt={item.product.name} className="w-full h-full object-cover" />
                  </div>
                  
                  <div className="flex-1 flex flex-col justify-between">
                    <div>
                      <span className="text-[9px] font-bold text-stone-400 uppercase tracking-widest block">{item.product.brand}</span>
                      <h4 className="text-[11px] font-semibold text-stone-800 uppercase truncate max-w-[180px] leading-tight mb-1">
                        {item.product.name}
                      </h4>
                      <span className="inline-block bg-[#ece8e1] text-stone-900 font-mono text-[9px] font-bold px-1.5 py-0.5 uppercase tracking-wide">
                        Size: {item.selectedSize}
                      </span>
                    </div>

                    <div className="flex justify-between items-end mt-2">
                      {/* Quantity buttons */}
                      <div className="flex items-center border border-stone-200 bg-white">
                        <button
                          onClick={() => onUpdateQty(item.product.id, item.selectedSize, item.quantity - 1)}
                          className="px-2 py-0.5 hover:bg-stone-50 transition-colors text-stone-600 font-bold font-mono text-xs"
                        >
                          -
                        </button>
                        <span className="px-3 py-0.5 text-[10px] font-bold font-mono text-stone-800 bg-[#fafaf9]">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => onUpdateQty(item.product.id, item.selectedSize, item.quantity + 1)}
                          className="px-2 py-0.5 hover:bg-stone-50 transition-colors text-stone-600 font-bold font-mono text-xs"
                        >
                          +
                        </button>
                      </div>

                      {/* Subtotal */}
                      <span className="text-[11px] font-mono font-semibold text-stone-900 shrink-0">
                        ₹{(activePrice * item.quantity).toLocaleString('en-IN')}
                      </span>
                    </div>
                  </div>

                  {/* Remove cross */}
                  <button
                    onClick={() => onRemoveItem(item.product.id, item.selectedSize)}
                    className="p-1 text-stone-300 hover:text-stone-900 absolute top-2 right-2 transition-colors"
                    title="Remove item"
                  >
                    <X size={14} />
                  </button>
                </div>
              );
            })
          )}
        </div>

        {/* Footer actions */}
        {cart.length > 0 && (
          <div className="border-t border-stone-200 bg-white p-5 space-y-4 shrink-0">
            <div className="space-y-1.5 text-[11px] font-sans text-stone-500 font-semibold uppercase tracking-wider">
              <div className="flex justify-between">
                <span>Basket Subtotal:</span>
                <span className="font-mono text-stone-800 font-bold">₹{baseSubtotal.toLocaleString('en-IN')}</span>
              </div>
              
              {automaticDiscount > 0 && (
                <div className="flex justify-between text-stone-900 font-extrabold">
                  <span>Automatic Multi-Buy Discount:</span>
                  <span>-₹{automaticDiscount.toLocaleString('en-IN')}</span>
                </div>
              )}

              <div className="flex justify-between">
                <span>Bangalore Delivery Fee:</span>
                <span className="font-mono text-stone-800 font-bold">
                  {shippingCharge === 0 ? <strong className="text-stone-900 uppercase">COMPLIMENTARY</strong> : `₹${shippingCharge}`}
                </span>
              </div>
              
              <div className="flex justify-between text-stone-500 text-[10px] font-bold uppercase">
                <span>🎁 Earned Super Drip Points:</span>
                <span>+{earnedPoints} PTS</span>
              </div>

              <div className="flex justify-between text-xs sm:text-sm border-t border-stone-100 pt-3 text-stone-900 font-extrabold uppercase tracking-widest">
                <span>GRAND TOTAL:</span>
                <span className="font-mono text-black text-sm">₹{grandTotal.toLocaleString('en-IN')}</span>
              </div>
            </div>

            {/* Checkout Button */}
            <button
              onClick={handleCheckoutInitiate}
              className="w-full bg-black hover:bg-stone-800 text-white font-sans text-[10px] font-bold uppercase tracking-widest py-4 transition-colors flex items-center justify-center gap-2"
              id="cart-checkout"
            >
              <MessageSquare size={13} className="fill-white text-white" /> SECURE DEAL ON WHATSAPP
            </button>
          </div>
        )}
      </div>

      {/* Cart Name/Phone checkout prompt */}
      {showPrompt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div 
            className="absolute inset-0 bg-black/40 transition-opacity"
            onClick={() => setShowPrompt(false)}
          />

          <div className="relative bg-white border border-stone-200 rounded-none shadow-2xl p-6 sm:p-8 w-full max-w-md z-10 animate-fade-in">
            <h3 className="font-serif italic text-lg text-stone-900 mb-2">
              Connect Bag to WhatsApp
            </h3>
            <p className="text-[11px] text-stone-500 leading-relaxed mb-6">
              Enter your details to log this cart order on the showroom registry. Our Bangalore team will immediately verify stock and send pickup/UPI details!
            </p>

            <form onSubmit={handleWhatsAppCheckoutSubmit} className="space-y-4">
              {formError && (
                <div className="bg-stone-50 border border-stone-200 text-stone-600 text-xs px-3 py-2 rounded-none font-sans">
                  {formError}
                </div>
              )}

              <div>
                <label className="block text-[9px] font-bold text-stone-400 tracking-widest uppercase mb-1">YOUR FULL NAME</label>
                <input 
                  type="text"
                  placeholder="Virat Kohli"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="w-full border border-stone-200 rounded-none px-3.5 py-2.5 text-xs focus:outline-none focus:border-stone-800 font-sans"
                  required
                />
              </div>

              <div>
                <label className="block text-[9px] font-bold text-stone-400 tracking-widest uppercase mb-1">WHATSAPP MOBILE NUMBER</label>
                <div className="relative flex">
                  <span className="inline-flex items-center px-3.5 rounded-none border border-r-0 border-stone-200 bg-stone-50 text-stone-500 text-[11px] font-mono">
                    +91
                  </span>
                  <input 
                    type="tel"
                    placeholder="9876543210"
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value.replace(/\D/g, '').slice(0, 10))}
                    className="w-full border border-stone-200 rounded-none px-3.5 py-2.5 text-xs focus:outline-none focus:border-stone-800 font-mono"
                    required
                  />
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowPrompt(false)}
                  className="flex-1 border border-stone-200 hover:bg-stone-50 text-stone-600 text-[10px] font-bold uppercase py-3.5"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-black text-[#fafaf9] text-[10px] font-bold uppercase py-3.5"
                >
                  COMPLETE CHECKOUT
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
