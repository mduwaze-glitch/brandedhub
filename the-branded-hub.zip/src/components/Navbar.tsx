import React, { useState, useEffect } from 'react';
import { ShoppingBag, Search, Menu, X, ChevronDown, User, MapPin, PhoneCall, Award, Map, Navigation } from 'lucide-react';

interface NavbarProps {
  currentPage: string;
  setCurrentPage: (page: string) => void;
  setCurrentSubcategory: (sub: string | null) => void;
  cartCount: number;
  setCartOpen: (open: boolean) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
}

export default function Navbar({
  currentPage,
  setCurrentPage,
  setCurrentSubcategory,
  cartCount,
  setCartOpen,
  searchQuery,
  setSearchQuery,
}: NavbarProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
  
  // Omnichannel Bangalore store selection (Sleek minimalist style!)
  const [selectedStore, setSelectedStore] = useState(() => {
    return localStorage.getItem('tbh_selected_store') || 'Jayanagar 3rd Block';
  });
  const [showStorePicker, setShowStorePicker] = useState(false);

  const handleStoreChange = (store: string) => {
    setSelectedStore(store);
    localStorage.setItem('tbh_selected_store', store);
    setShowStorePicker(false);
    window.dispatchEvent(new Event('store-changed'));
  };

  const navigation = {
    clothing: ['Shirts', 'T-Shirts', 'Oversized T-Shirts', 'Hoodies', 'Pants'],
    shoes: ['Air Jordan', 'Sport Shoes', 'Formal Shoes'],
    accessories: ['Wallets', 'Belts', 'Hats'],
  };

  const handleNavClick = (page: string, subcategory: string | null = null) => {
    setCurrentPage(page);
    setCurrentSubcategory(subcategory);
    setMobileMenuOpen(false);
    setActiveDropdown(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-[#fafaf9] border-b border-stone-200">
      
      {/* 1. TOP UTILITY BAR (Very clean and minimalist like Zanerobe) */}
      <div className="w-full bg-[#111111] text-[#fafaf9] text-[10px] font-sans tracking-widest uppercase">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-between items-center h-9">
          <div className="flex h-full items-center gap-1 sm:gap-4">
            <span className="text-[10px] font-normal text-stone-400">
              Free Shipping Available inside Bangalore - Read More
            </span>
          </div>
          
          <div className="hidden md:flex items-center gap-5 text-stone-300 font-medium tracking-widest text-[9px]">
            <span className="flex items-center gap-1.5 hover:text-white transition-colors cursor-pointer">
              <PhoneCall size={10} className="text-stone-400" /> Support: +91 87718 18491
            </span>
            <span className="text-stone-700">|</span>
            <span className="flex items-center gap-1.5 text-stone-200 font-semibold">
              <Award size={10} className="text-stone-400" /> Namma Bangalore's Curated Drops
            </span>
          </div>
        </div>
      </div>

      {/* 2. SUBTLE PROMO ALERT TICKER (Clean, sand-colored bar matching ZANEROBE image feel) */}
      <div className="w-full bg-[#ece8e1] text-[#111111] py-2 px-4 border-b border-stone-200/50">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row justify-center items-center text-center gap-1.5 sm:gap-4 font-sans">
          <span className="bg-[#111111] text-white text-[8px] px-2 py-0.5 font-bold tracking-widest uppercase">
            LIMITED EDITION
          </span>
          <p className="text-[10px] sm:text-[11px] font-semibold tracking-widest uppercase text-stone-800">
            ₹500 OFF EVERY ₹2,000 SPENT + INSTANT 2-HOUR SHOWROOM PICKUP
          </p>
          <button 
            onClick={() => handleNavClick('clothing')}
            className="text-[10px] font-bold uppercase underline hover:text-stone-600 tracking-widest transition-colors"
          >
            Explore Drops
          </button>
        </div>
      </div>

      {/* 3. MAIN HEADER ROW */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        
        {/* Left Side: Brand Logo */}
        <div className="flex items-center gap-6">
          <div 
            onClick={() => handleNavClick('home')}
            className="flex items-center cursor-pointer select-none"
            id="nav-logo"
          >
            <div className="flex flex-col">
              <span className="text-base sm:text-lg tracking-[0.25em] font-extrabold uppercase leading-none text-[#111111]">
                THE BRANDED HUB
              </span>
              <span className="text-[8px] tracking-[0.18em] font-mono font-medium text-stone-500 uppercase mt-1">
                STREETWEAR & SNEAKERS
              </span>
            </div>
          </div>
        </div>

        {/* Center: Desktop Navigation links (Zanerobe layout style) */}
        <nav className="hidden lg:flex items-center gap-8 h-full">
          <button 
            onClick={() => handleNavClick('home')}
            className={`text-[11px] font-bold uppercase tracking-widest transition-colors h-full flex items-center border-b-2 ${currentPage === 'home' ? 'border-[#111111] text-[#111111]' : 'border-transparent text-stone-600 hover:text-[#111111]'}`}
          >
            Home
          </button>

          {/* Men Category Tab */}
          <div 
            className="h-full relative"
            onMouseEnter={() => setActiveDropdown('men')}
            onMouseLeave={() => setActiveDropdown(null)}
          >
            <button 
              onClick={() => handleNavClick('clothing')}
              className={`flex items-center gap-1 text-[11px] font-bold uppercase tracking-widest transition-colors h-full border-b-2 ${currentPage === 'clothing' && !searchQuery ? 'border-[#111111] text-[#111111]' : 'border-transparent text-stone-600 hover:text-[#111111]'}`}
            >
              Apparel <ChevronDown size={10} className="text-stone-400" />
            </button>
            {activeDropdown === 'men' && (
              <div className="absolute top-full left-0 w-48 bg-[#fafaf9] border border-stone-200 shadow-lg py-2 animate-fade-in z-50">
                {navigation.clothing.map((sub) => (
                  <button
                    key={sub}
                    onClick={() => handleNavClick('clothing', sub)}
                    className="w-full text-left px-4 py-2 text-[10px] font-semibold text-stone-600 hover:bg-[#ece8e1] hover:text-[#111111] transition-colors uppercase tracking-wider"
                  >
                    {sub}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Shoes Category Tab */}
          <div 
            className="h-full relative"
            onMouseEnter={() => setActiveDropdown('shoes')}
            onMouseLeave={() => setActiveDropdown(null)}
          >
            <button 
              onClick={() => handleNavClick('shoes')}
              className={`flex items-center gap-1 text-[11px] font-bold uppercase tracking-widest transition-colors h-full border-b-2 ${currentPage === 'shoes' ? 'border-[#111111] text-[#111111]' : 'border-transparent text-stone-600 hover:text-[#111111]'}`}
            >
              Kicks <ChevronDown size={10} className="text-stone-400" />
            </button>
            {activeDropdown === 'shoes' && (
              <div className="absolute top-full left-0 w-48 bg-[#fafaf9] border border-stone-200 shadow-lg py-2 animate-fade-in z-50">
                {navigation.shoes.map((sub) => (
                  <button
                    key={sub}
                    onClick={() => handleNavClick('shoes', sub)}
                    className="w-full text-left px-4 py-2 text-[10px] font-semibold text-stone-600 hover:bg-[#ece8e1] hover:text-[#111111] transition-colors uppercase tracking-wider"
                  >
                    {sub}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Accessories Category Tab */}
          <div 
            className="h-full relative"
            onMouseEnter={() => setActiveDropdown('accessories')}
            onMouseLeave={() => setActiveDropdown(null)}
          >
            <button 
              onClick={() => handleNavClick('accessories')}
              className={`flex items-center gap-1 text-[11px] font-bold uppercase tracking-widest transition-colors h-full border-b-2 ${currentPage === 'accessories' ? 'border-[#111111] text-[#111111]' : 'border-transparent text-stone-600 hover:text-[#111111]'}`}
            >
              Accs <ChevronDown size={10} className="text-stone-400" />
            </button>
            {activeDropdown === 'accessories' && (
              <div className="absolute top-full left-0 w-48 bg-[#fafaf9] border border-stone-200 shadow-lg py-2 animate-fade-in z-50">
                {navigation.accessories.map((sub) => (
                  <button
                    key={sub}
                    onClick={() => handleNavClick('accessories', sub)}
                    className="w-full text-left px-4 py-2 text-[10px] font-semibold text-stone-600 hover:bg-[#ece8e1] hover:text-[#111111] transition-colors uppercase tracking-wider"
                  >
                    {sub}
                  </button>
                ))}
              </div>
            )}
          </div>

          <button 
            onClick={() => handleNavClick('about')}
            className={`text-[11px] font-bold uppercase tracking-widest transition-colors h-full flex items-center border-b-2 ${currentPage === 'about' ? 'border-[#111111] text-[#111111]' : 'border-transparent text-stone-600 hover:text-[#111111]'}`}
          >
            Story
          </button>

          <button 
            onClick={() => handleNavClick('contact')}
            className={`text-[11px] font-bold uppercase tracking-widest transition-colors h-full flex items-center border-b-2 ${currentPage === 'contact' ? 'border-[#111111] text-[#111111]' : 'border-transparent text-stone-600 hover:text-[#111111]'}`}
          >
            Stores
          </button>

          <button 
            onClick={() => handleNavClick('blog')}
            className={`text-[11px] font-bold uppercase tracking-widest transition-colors h-full flex items-center border-b-2 ${currentPage === 'blog' ? 'border-[#111111] text-[#111111]' : 'border-transparent text-stone-600 hover:text-[#111111]'}`}
          >
            Edits
          </button>
        </nav>

        {/* Right Side Actions: Search, Store, Cart, Menu */}
        <div className="flex items-center gap-3 sm:gap-5 justify-end">
          
          {/* Subtle Minimalist Store Selector Widget */}
          <div className="relative hidden md:block shrink-0">
            <button
              onClick={() => setShowStorePicker(!showStorePicker)}
              className="flex items-center gap-1.5 text-left border border-stone-200 hover:border-stone-400 px-3 py-1.5 bg-stone-50 transition-colors text-[10px] uppercase tracking-wider"
              title="Select pickup showroom"
              id="store-picker-button"
            >
              <MapPin size={11} className="text-stone-600 shrink-0" />
              <div>
                <span className="text-[11px] text-stone-800 font-bold font-sans tracking-wide">{selectedStore}</span>
              </div>
              <ChevronDown size={11} className="text-stone-400 ml-0.5 shrink-0" />
            </button>
            {showStorePicker && (
              <div className="absolute top-full mt-2 right-0 w-64 bg-[#fafaf9] border border-stone-200 shadow-xl p-3.5 z-50 animate-fade-in text-xs">
                <h4 className="font-bold text-stone-800 uppercase tracking-widest text-[10px] mb-2 pb-1.5 border-b border-stone-200">Our Showrooms</h4>
                <div className="space-y-1.5">
                  {[
                    { name: 'Jayanagar 3rd Block', hours: '11:00 AM - 09:30 PM', info: 'Opposite Central Library' },
                    { name: 'BTM Layout 2nd Stage', hours: '11:00 AM - 09:30 PM', info: 'Off 100 Feet Ring Road' }
                  ].map(st => (
                    <button
                      key={st.name}
                      onClick={() => handleStoreChange(st.name)}
                      className={`w-full text-left p-2.5 border transition-colors ${selectedStore === st.name ? 'border-[#111111] bg-[#ece8e1] text-[#111111] font-bold' : 'border-stone-100 hover:bg-stone-50'}`}
                    >
                      <div className="font-bold uppercase text-[10px] tracking-wide">{st.name}</div>
                      <div className="text-[9px] text-stone-500 mt-0.5">{st.hours}</div>
                      <div className="text-[9px] text-stone-400 italic mt-0.5">{st.info}</div>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Elegant Search Bar */}
          <div className="flex items-center bg-stone-50 border border-stone-200 focus-within:border-stone-400 px-3 py-1.5 w-32 sm:w-44 transition-all">
            <Search size={13} className="text-stone-400 mr-2 shrink-0" />
            <input 
              type="text" 
              placeholder="SEARCH DROPS..."
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                if (currentPage !== 'clothing' && currentPage !== 'shoes' && currentPage !== 'accessories') {
                  setCurrentPage('clothing');
                }
              }}
              className="bg-transparent text-[10px] tracking-wider text-stone-800 focus:outline-none w-full font-sans font-medium uppercase placeholder-stone-400"
            />
          </div>

          {/* Sign In Link */}
          <button 
            onClick={() => handleNavClick('admin')}
            className="flex items-center gap-1 text-stone-600 hover:text-[#111111] transition-colors shrink-0"
            title="Showroom Panel"
            id="nav-admin"
          >
            <User size={15} />
            <span className="text-[10px] font-bold tracking-widest uppercase hidden sm:inline">Sign In</span>
          </button>

          {/* Minimalist Shopping Bag Button */}
          <button 
            onClick={() => setCartOpen(true)}
            className="flex items-center gap-2 border border-stone-800 text-[#111111] hover:bg-[#ece8e1] px-3.5 py-1.5 transition-colors relative shrink-0 font-bold"
            title="Shopping Bag"
            id="nav-cart"
          >
            <ShoppingBag size={14} />
            <span className="text-[10px] uppercase tracking-widest font-extrabold">Bag ({cartCount})</span>
          </button>

          {/* Mobile Menu Toggle */}
          <button 
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-1.5 text-stone-800 hover:bg-stone-50 shrink-0 border border-stone-200"
          >
            {mobileMenuOpen ? <X size={18} /> : <Menu size={18} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-stone-200 bg-[#fafaf9] px-4 py-4 space-y-4 animate-fade-in max-h-[calc(100vh-6rem)] overflow-y-auto shadow-lg">
          {/* Selected store tracker inside mobile view */}
          <div className="bg-[#ece8e1] p-3 border border-stone-200 flex justify-between items-center text-xs">
            <div>
              <span className="text-[9px] text-stone-500 font-bold uppercase block leading-tight">Showroom:</span>
              <span className="font-black text-stone-800 text-[10px] uppercase tracking-wide">{selectedStore}</span>
            </div>
            <button
              onClick={() => {
                const next = selectedStore.includes('Jayanagar') ? 'BTM Layout 2nd Stage' : 'Jayanagar 3rd Block';
                handleStoreChange(next);
              }}
              className="bg-[#111111] text-white text-[9px] font-bold px-2 py-1 uppercase tracking-wider"
            >
              Switch
            </button>
          </div>

          {/* Navigation Links */}
          <div className="space-y-1">
            <button 
              onClick={() => handleNavClick('home')}
              className="w-full text-left py-2.5 text-xs font-black text-stone-800 uppercase border-b border-stone-100 tracking-widest"
            >
              Home Page
            </button>

            {/* Clothing Category */}
            <div className="py-2.5">
              <span className="text-[9px] font-black text-stone-400 tracking-widest uppercase block mb-1">Apparel Drops</span>
              <div className="grid grid-cols-2 gap-2 pl-2">
                {navigation.clothing.map(sub => (
                  <button 
                    key={sub}
                    onClick={() => handleNavClick('clothing', sub)}
                    className="text-left text-xs font-bold text-stone-600 py-1 hover:text-[#111111] uppercase tracking-wide"
                  >
                    {sub}
                  </button>
                ))}
              </div>
            </div>

            {/* Shoes Category */}
            <div className="py-2.5 border-t border-stone-100">
              <span className="text-[9px] font-black text-stone-400 tracking-widest uppercase block mb-1">Kicks & Sneakers</span>
              <div className="grid grid-cols-2 gap-2 pl-2">
                {navigation.shoes.map(sub => (
                  <button 
                    key={sub}
                    onClick={() => handleNavClick('shoes', sub)}
                    className="text-left text-xs font-bold text-stone-600 py-1 hover:text-[#111111] uppercase tracking-wide"
                  >
                    {sub}
                  </button>
                ))}
              </div>
            </div>

            {/* Accessories Category */}
            <div className="py-2.5 border-t border-zinc-100">
              <span className="text-[9px] font-black text-stone-400 tracking-widest uppercase block mb-1">Accessories</span>
              <div className="grid grid-cols-2 gap-2 pl-2">
                {navigation.accessories.map(sub => (
                  <button 
                    key={sub}
                    onClick={() => handleNavClick('accessories', sub)}
                    className="text-left text-xs font-bold text-stone-600 py-1 hover:text-[#111111] uppercase tracking-wide"
                  >
                    {sub}
                  </button>
                ))}
              </div>
            </div>

            <button 
              onClick={() => handleNavClick('about')}
              className="w-full text-left py-3.5 text-xs font-black text-stone-800 uppercase border-t border-b border-stone-100 tracking-widest"
            >
              Our Story
            </button>

            <button 
              onClick={() => handleNavClick('contact')}
              className="w-full text-left py-3.5 text-xs font-black text-stone-800 uppercase border-b border-stone-100 tracking-widest"
            >
              Our Showrooms
            </button>

            <button 
              onClick={() => handleNavClick('blog')}
              className="w-full text-left py-3.5 text-xs font-black text-stone-800 uppercase border-b border-stone-100 tracking-widest"
            >
              Style Edits
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
