import React, { useState, useEffect } from 'react';
import { Product } from '../types';
import { Sparkles, ArrowRight, MapPin, Shield, TrendingUp, Star, Gift, Truck, ShoppingBag, ArrowLeftRight } from 'lucide-react';

interface HomeViewProps {
  products: Product[];
  onSelectProduct: (slug: string) => void;
  onNavigatePage: (page: string, sub: string | null) => void;
}

export default function HomeView({ products, onSelectProduct, onNavigatePage }: HomeViewProps) {
  // Real-time Cart tracking to show Loyalty Points progress elegantly!
  const [cartSubtotal, setCartSubtotal] = useState(0);

  useEffect(() => {
    const updateCartValue = () => {
      const savedCart = localStorage.getItem('tbh_cart');
      if (savedCart) {
        try {
          const items = JSON.parse(savedCart);
          const subtotal = items.reduce((sum: number, item: any) => {
            const price = item.product.discounted_price || item.product.price;
            return sum + (price * item.quantity);
          }, 0);
          setCartSubtotal(subtotal);
        } catch (e) {
          console.error(e);
        }
      } else {
        setCartSubtotal(0);
      }
    };

    updateCartValue();
    window.addEventListener('storage', updateCartValue);
    const interval = setInterval(updateCartValue, 2000);
    return () => {
      window.removeEventListener('storage', updateCartValue);
      clearInterval(interval);
    };
  }, []);

  // Sleek neutral Loyalty rewards tracker (Zanerobe vibe)
  const nextMilestone = cartSubtotal < 1500 ? 1500 : cartSubtotal < 3000 ? 3000 : 4500;
  const progressPercent = Math.min((cartSubtotal / nextMilestone) * 100, 100);
  const currentEarnedCash = cartSubtotal >= 3000 ? 1000 : cartSubtotal >= 1500 ? 500 : 0;
  const remainingForNext = nextMilestone - cartSubtotal;

  // Filter products for sections
  const featuredDrops = products.filter(p => p.is_featured && p.status === 'active').slice(0, 4);
  const bestSellers = products.filter(p => p.status === 'active').slice(2, 6);

  return (
    <div className="w-full bg-[#fafaf9] animate-fade-in text-[#111111]" id="home-view">
      
      {/* 1. SHIPPING INFO RIBBON - Slim, neutral, minimalist */}
      <div className="bg-[#fafaf9] py-2.5 px-4 border-b border-stone-200 text-stone-600 text-[10px] select-none uppercase tracking-widest">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-2 font-semibold">
          <div className="flex items-center gap-1.5">
            <Truck size={12} className="text-stone-500 shrink-0" />
            <span>Standard home delivery inside Bangalore is fully complimentary over ₹1,999</span>
          </div>
          <div className="text-stone-300 hidden md:block">|</div>
          <div className="flex items-center gap-1.5">
            <MapPin size={12} className="text-stone-500 shrink-0" />
            <span>Showroom Pickup: ready within 2 hours at Jayanagar or BTM Layout</span>
          </div>
        </div>
      </div>

      {/* 2. PREMIUM STREETWEAR HERO SLIDER (Beautifully matching the Zanerobe style) */}
      <section className="relative w-full h-[550px] sm:h-[650px] bg-stone-900 overflow-hidden flex items-center justify-center">
        {/* Desaturated, warm desaturated background image of streetwear models */}
        <div className="absolute inset-0">
          <img 
            src="https://images.unsplash.com/photo-1516257984-b1b4d707412e?auto=format&fit=crop&q=80&w=1500" 
            alt="The Branded Hub Streetwear Editorial" 
            className="w-full h-full object-cover object-center opacity-80 brightness-75 contrast-105 select-none"
          />
          {/* Subtle warm tint overlay */}
          <div className="absolute inset-0 bg-[#3a342c]/20 mix-blend-color-burn"></div>
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-black/10"></div>
        </div>

        <div className="relative z-10 max-w-4xl mx-auto text-center px-4 flex flex-col items-center">
          <span className="text-[10px] sm:text-xs font-bold text-stone-200 tracking-[0.3em] uppercase block mb-4">
            LIMITED EDITION EXCLUSIVE
          </span>
          
          <h1 className="font-serif italic text-4xl sm:text-7xl font-light text-white tracking-tight leading-none mb-2 drop-shadow-sm select-none">
            The Legacy Capsule
          </h1>
          
          <p className="font-sans text-[10px] sm:text-xs tracking-[0.25em] text-stone-200 uppercase mb-8 max-w-lg leading-relaxed font-semibold">
            ESTABLISHED '22 • BANGALORE STREET CULTURE
          </p>

          <button
            onClick={() => onNavigatePage('clothing', null)}
            className="bg-white hover:bg-[#ece8e1] text-black text-[10px] sm:text-xs font-bold tracking-[0.2em] uppercase px-8 py-3.5 transition-all shadow-sm rounded-none border border-transparent"
          >
            SHOP THE RE-STOCK
          </button>
        </div>

        <div className="absolute bottom-4 left-0 right-0 text-center select-none">
          <span className="text-[9px] text-stone-400 font-mono tracking-widest uppercase">
            Scroll to explore collections
          </span>
        </div>
      </section>

      {/* 3. "SHOP THE LEGACY CAPSULE" SECTION (Row of products with clean layouts) */}
      <section className="py-16 bg-[#fafaf9] border-b border-stone-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          {/* Section title exactly like image */}
          <div className="text-center mb-10">
            <h2 className="text-xs sm:text-sm font-extrabold tracking-[0.25em] uppercase text-stone-900">
              SHOP THE LEGACY CAPSULE
            </h2>
            <div className="w-12 h-0.5 bg-stone-300 mx-auto mt-3"></div>
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-x-4 gap-y-10 sm:gap-x-6 sm:gap-y-12">
            {featuredDrops.map(product => {
              const discountPercent = product.discounted_price 
                ? Math.round(((product.price - product.discounted_price) / product.price) * 100) 
                : 0;

              return (
                <div
                  key={product.id}
                  onClick={() => onSelectProduct(product.slug)}
                  className="group cursor-pointer flex flex-col"
                >
                  {/* Clean studio card image exactly like Zanerobe product list */}
                  <div className="relative aspect-[3/4] bg-[#f2ede4]/40 border border-stone-200/40 overflow-hidden mb-4">
                    <img
                      src={product.images[0]}
                      alt={product.name}
                      className="w-full h-full object-cover object-center transform group-hover:scale-102 transition-transform duration-500"
                      loading="lazy"
                    />
                    
                    {/* Minimalist text discount tag instead of red badge */}
                    {discountPercent > 0 && (
                      <span className="absolute top-3 left-3 bg-[#111111] text-[#fafaf9] text-[8px] font-bold tracking-widest uppercase px-2 py-0.5">
                        {discountPercent}% OFF
                      </span>
                    )}
                  </div>

                  {/* Clean details text */}
                  <div className="text-center space-y-1">
                    <span className="text-[9px] font-bold text-stone-400 tracking-widest uppercase block">
                      {product.brand}
                    </span>
                    <h3 className="text-[11px] font-semibold text-stone-800 tracking-wide hover:text-stone-500 transition-colors uppercase truncate max-w-full px-1">
                      {product.name}
                    </h3>
                    
                    {/* Neutral Price display */}
                    <div className="flex items-center justify-center gap-2 text-[10px] font-mono tracking-wider font-semibold">
                      {product.discounted_price ? (
                        <>
                          <span className="text-stone-900">
                            ₹{product.discounted_price.toLocaleString('en-IN')}
                          </span>
                          <span className="text-stone-400 line-through">
                            ₹{product.price.toLocaleString('en-IN')}
                          </span>
                        </>
                      ) : (
                        <span className="text-stone-800">
                          ₹{product.price.toLocaleString('en-IN')}
                        </span>
                      )}
                    </div>

                    {/* Size options at the bottom of the card, just like in the Zanerobe image */}
                    <div className="pt-2 text-[8px] font-bold text-stone-400 uppercase tracking-widest flex justify-center gap-1.5 select-none">
                      {product.sizes.map((s, idx) => (
                        <span key={idx} className={s.stock > 0 ? 'text-stone-600' : 'text-stone-300 line-through'}>
                          {s.size}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* 4. EXQUISITE EDITORIAL STORY GRID (The "Nate Robinson" aesthetic break in the image) */}
      <section className="relative w-full h-[500px] bg-stone-950 overflow-hidden flex items-center">
        <div className="absolute inset-0">
          <img 
            src="https://images.unsplash.com/photo-1529139574466-a303027c1d8b?auto=format&fit=crop&q=80&w=1200" 
            alt="The Branded Hub Friends & Edits" 
            className="w-full h-full object-cover object-center opacity-70 filter brightness-75 select-none"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/40 to-transparent"></div>
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
          <div className="max-w-md text-left space-y-4">
            <span className="text-[9px] font-bold text-stone-300 tracking-[0.3em] uppercase block">
              THE BRANDED HUB & FRIENDS
            </span>
            
            <h2 className="font-serif text-3xl sm:text-5xl font-light text-white leading-tight">
              Bangalore's Creative Edit
            </h2>
            
            <p className="text-[11px] sm:text-xs text-stone-300 tracking-wider leading-relaxed font-sans font-medium">
              Capturing authentic subcultures in Jayanagar. Presenting relaxed silhouettes, premium heavyweight loops and heavy-duty graphics.
            </p>

            <div className="pt-4">
              <button
                onClick={() => onNavigatePage('blog', null)}
                className="bg-white hover:bg-stone-100 text-black text-[10px] font-bold tracking-[0.2em] uppercase px-6 py-3 transition-colors rounded-none"
              >
                EXPLORE THE EDIT
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* 5. "SHOP THE EDIT" CATALOG SECTION */}
      <section className="py-16 bg-[#fafaf9] border-b border-stone-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center mb-10">
            <h2 className="text-xs sm:text-sm font-extrabold tracking-[0.25em] uppercase text-stone-900">
              SHOP THE BANGALORE EDIT
            </h2>
            <div className="w-12 h-0.5 bg-stone-300 mx-auto mt-3"></div>
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-x-4 gap-y-10 sm:gap-x-6 sm:gap-y-12">
            {bestSellers.map(product => {
              const discountPercent = product.discounted_price 
                ? Math.round(((product.price - product.discounted_price) / product.price) * 100) 
                : 0;

              return (
                <div
                  key={product.id}
                  onClick={() => onSelectProduct(product.slug)}
                  className="group cursor-pointer flex flex-col"
                >
                  <div className="relative aspect-[3/4] bg-[#f2ede4]/40 border border-stone-200/40 overflow-hidden mb-4">
                    <img
                      src={product.images[0]}
                      alt={product.name}
                      className="w-full h-full object-cover object-center transform group-hover:scale-102 transition-transform duration-500"
                      loading="lazy"
                    />
                    {discountPercent > 0 && (
                      <span className="absolute top-3 left-3 bg-[#111111] text-[#fafaf9] text-[8px] font-bold tracking-widest uppercase px-2 py-0.5">
                        {discountPercent}% OFF
                      </span>
                    )}
                  </div>

                  <div className="text-center space-y-1">
                    <span className="text-[9px] font-bold text-stone-400 tracking-widest uppercase block">
                      {product.brand}
                    </span>
                    <h3 className="text-[11px] font-semibold text-stone-800 tracking-wide hover:text-stone-500 transition-colors uppercase truncate max-w-full px-1">
                      {product.name}
                    </h3>
                    
                    <div className="flex items-center justify-center gap-2 text-[10px] font-mono tracking-wider font-semibold">
                      {product.discounted_price ? (
                        <>
                          <span className="text-stone-900">
                            ₹{product.discounted_price.toLocaleString('en-IN')}
                          </span>
                          <span className="text-stone-400 line-through">
                            ₹{product.price.toLocaleString('en-IN')}
                          </span>
                        </>
                      ) : (
                        <span className="text-stone-800">
                          ₹{product.price.toLocaleString('en-IN')}
                        </span>
                      )}
                    </div>

                    <div className="pt-2 text-[8px] font-bold text-stone-400 uppercase tracking-widest flex justify-center gap-1.5 select-none">
                      {product.sizes.map((s, idx) => (
                        <span key={idx} className={s.stock > 0 ? 'text-stone-600' : 'text-stone-300 line-through'}>
                          {s.size}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* 6. MINIMALIST CATEGORY SELECTION DEALS - Clean grid */}
      <section className="py-16 bg-[#fafaf9] border-b border-stone-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <span className="text-stone-500 text-[9px] font-bold tracking-[0.3em] uppercase block mb-1">STREET APPAREL & KICKS</span>
            <h2 className="text-xs sm:text-sm font-extrabold tracking-[0.25em] uppercase text-stone-900">
              DISCOVER CORE CATEGORIES
            </h2>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            {[
              {
                title: "Oversized Tees",
                desc: "Heavyweight 240 GSM organic comfort",
                sub: "Oversized T-Shirts",
                category: "clothing",
                img: "https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&q=80&w=600"
              },
              {
                title: "Retro Jordans",
                desc: "100% physically authenticated drops",
                sub: "Air Jordan",
                category: "shoes",
                img: "https://images.unsplash.com/photo-1597045566677-8cf032ed6634?auto=format&fit=crop&q=80&w=600"
              },
              {
                title: "Street Accessories",
                desc: "Caps, wallets & premium utility belts",
                sub: null,
                category: "accessories",
                img: "https://images.unsplash.com/photo-1614162692292-7ac56d7f7f1e?auto=format&fit=crop&q=80&w=600"
              }
            ].map((cat, idx) => (
              <div 
                key={idx}
                onClick={() => onNavigatePage(cat.category, cat.sub)}
                className="relative h-[320px] bg-stone-100 cursor-pointer overflow-hidden group border border-stone-200"
              >
                <img 
                  src={cat.img} 
                  alt={cat.title} 
                  className="w-full h-full object-cover object-center transform group-hover:scale-103 transition-transform duration-500 opacity-90 brightness-95"
                />
                <div className="absolute inset-0 bg-black/10 group-hover:bg-black/25 transition-colors"></div>
                <div className="absolute bottom-6 left-6 text-white space-y-1">
                  <h3 className="font-serif text-lg italic text-white">{cat.title}</h3>
                  <p className="text-[10px] text-stone-200 font-sans tracking-wide uppercase">{cat.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 7. RE-STYLIZED SUPER DRIP CASH TRACKER CARD - Beautifully integrated into the Zanerobe grid */}
      <section className="py-16 bg-[#ece8e1] border-b border-stone-200 text-[#111111]">
        <div className="max-w-4xl mx-auto px-4">
          <div className="bg-white border border-stone-300 p-8 sm:p-12 text-center space-y-6">
            <span className="text-[10px] font-bold text-stone-500 tracking-[0.25em] uppercase block">
              THE BRANDED HUB REWARDS
            </span>
            
            <h2 className="font-serif italic text-2xl sm:text-4xl text-stone-900 leading-none">
              Super Drip Points System
            </h2>

            <p className="text-xs sm:text-sm font-medium text-stone-600 leading-relaxed max-w-xl mx-auto">
              Get an immediate <strong className="text-black font-bold">₹500 voucher</strong> credited for every <strong className="text-black font-bold">₹1,500 spent</strong> inside a single shopping bag session. Simple automatic discounts, zero codes necessary.
            </p>

            {/* Dynamic visual indicator */}
            <div className="bg-[#fafaf9] border border-stone-200 p-5 sm:p-6 max-w-md mx-auto space-y-3.5">
              <div className="flex justify-between text-[10px] font-bold text-stone-700 tracking-wider uppercase font-mono">
                <span>Active Bag: ₹{cartSubtotal.toLocaleString('en-IN')}</span>
                <span>Milestone: ₹{nextMilestone}</span>
              </div>
              
              <div className="w-full bg-stone-200 h-1.5 overflow-hidden">
                <div 
                  className="bg-black h-full transition-all duration-500" 
                  style={{ width: `${progressPercent}%` }}
                />
              </div>

              <div className="text-[10px] font-medium text-stone-500 tracking-wide">
                {cartSubtotal < 1500 ? (
                  <span>Add <strong className="text-stone-800 font-bold">₹{remainingForNext}</strong> worth of items to unlock your first automatic <strong className="text-stone-900 font-bold">₹500 drop</strong>!</span>
                ) : (
                  <span className="text-stone-800 font-bold">✓ YOU HAVE EARNED ₹{currentEarnedCash} OFF YOUR CART VALUE! Add ₹{remainingForNext} for the next tier.</span>
                )}
              </div>
            </div>

            <div className="pt-2">
              <button
                onClick={() => onNavigatePage('clothing', null)}
                className="bg-black hover:bg-stone-800 text-white text-[10px] font-bold tracking-[0.2em] uppercase px-8 py-3.5 transition-colors"
              >
                BROWSE OUR APPAREL
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* 8. CORE VALUES LIST - Pristine, minimal aesthetic strip */}
      <section className="py-16 bg-[#fafaf9]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-3 gap-10">
          
          <div className="space-y-3 text-center md:text-left">
            <div className="w-8 h-8 border border-stone-400 text-stone-700 flex items-center justify-center mx-auto md:mx-0">
              <Shield size={14} />
            </div>
            <h3 className="text-xs font-bold uppercase tracking-widest text-stone-900">Physically Verified</h3>
            <p className="text-stone-500 text-[11px] leading-relaxed font-medium">
              Every curated drop is manually authenticated and certified by our sneakerheads specialists before showing in store.
            </p>
          </div>

          <div className="space-y-3 text-center md:text-left">
            <div className="w-8 h-8 border border-stone-400 text-stone-700 flex items-center justify-center mx-auto md:mx-0">
              <MapPin size={14} />
            </div>
            <h3 className="text-xs font-bold uppercase tracking-widest text-stone-900">Showroom Reservals</h3>
            <p className="text-stone-500 text-[11px] leading-relaxed font-medium">
              Reserve your sizing with complete confidence online and walk in to inspect, try on, or pickup from our Bangalore showroom.
            </p>
          </div>

          <div className="space-y-3 text-center md:text-left">
            <div className="w-8 h-8 border border-stone-400 text-stone-700 flex items-center justify-center mx-auto md:mx-0">
              <TrendingUp size={14} />
            </div>
            <h3 className="text-xs font-bold uppercase tracking-widest text-stone-900">Instant WhatsApp Booking</h3>
            <p className="text-stone-500 text-[11px] leading-relaxed font-medium">
              Connect your shopping bag directly with our Bangalore showroom via WhatsApp link and secure instant UPI payment options.
            </p>
          </div>

        </div>
      </section>

      {/* 9. BOTTOM EDITORIAL HERO (Creator's Club Vol 3 style from Zanerobe) */}
      <section className="relative w-full h-[400px] bg-stone-900 overflow-hidden flex items-center justify-center">
        <div className="absolute inset-0">
          <img 
            src="https://images.unsplash.com/photo-1539109136881-3be0616acf4b?auto=format&fit=crop&q=80&w=1200" 
            alt="The Branded Hub Creator Club" 
            className="w-full h-full object-cover object-center opacity-70 filter brightness-75 select-none"
          />
        </div>
        <div className="relative z-10 text-center space-y-3 px-4">
          <span className="text-[10px] text-stone-300 font-bold uppercase tracking-[0.3em] block">
            THE SHOWROOM COMMUNITY
          </span>
          <h2 className="font-serif italic text-3xl sm:text-5xl text-white tracking-tight">
            Creator's Club Vol. 3
          </h2>
          <p className="text-[10px] text-stone-400 uppercase tracking-widest font-sans font-semibold pt-2">
            Join the movement • Visit Jayanagar today
          </p>
        </div>
      </section>

    </div>
  );
}
