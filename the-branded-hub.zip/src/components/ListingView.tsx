import React, { useState, useMemo, useEffect } from 'react';
import { Product } from '../types';
import { Filter, X, ChevronDown, Check, SlidersHorizontal, Sparkles, Star, MapPin, Truck } from 'lucide-react';

interface ListingViewProps {
  products: Product[];
  category: 'Clothing' | 'Shoes' | 'Accessories';
  subcategory: string | null;
  onSelectProduct: (slug: string) => void;
  searchQuery: string;
}

export default function ListingView({
  products,
  category,
  subcategory,
  onSelectProduct,
  searchQuery,
}: ListingViewProps) {
  const [mobileFiltersOpen, setMobileFiltersOpen] = useState(false);
  
  // Real-time store selection sync
  const [selectedStore, setSelectedStore] = useState(() => {
    return localStorage.getItem('tbh_selected_store') || 'Jayanagar 3rd Block';
  });

  useEffect(() => {
    const handleStoreChange = () => {
      setSelectedStore(localStorage.getItem('tbh_selected_store') || 'Jayanagar 3rd Block');
    };
    window.addEventListener('store-changed', handleStoreChange);
    return () => window.removeEventListener('store-changed', handleStoreChange);
  }, []);

  // Filter States
  const [selectedBrands, setSelectedBrands] = useState<string[]>([]);
  const [selectedSizes, setSelectedSizes] = useState<string[]>([]);
  const [selectedColors, setSelectedColors] = useState<string[]>([]);
  const [selectedAvailability, setSelectedAvailability] = useState<string[]>(['in-stock']); // Default to in-stock for premium UX
  
  // Omnichannel Shopping Preference Filter (Sleek minimalist toggle)
  const [shoppingMode, setShoppingMode] = useState<'all' | 'ship' | 'pickup'>('all');

  const [maxPrice, setMaxPrice] = useState<number>(25000);
  const [sortOption, setSortOption] = useState<string>('featured');

  // Dynamically extract all available brands, sizes, colors for the current category context
  const contextProducts = useMemo(() => {
    return products.filter(p => {
      // Base category filter
      if (p.category.toLowerCase() !== category.toLowerCase()) return false;
      // Subcategory filter (if selected)
      if (subcategory && p.subcategory.toLowerCase() !== subcategory.toLowerCase()) return false;
      // Global search string filter
      if (searchQuery) {
        const query = searchQuery.toLowerCase();
        return (
          p.name.toLowerCase().includes(query) ||
          p.brand.toLowerCase().includes(query) ||
          p.subcategory.toLowerCase().includes(query) ||
          p.description.toLowerCase().includes(query)
        );
      }
      return p.status !== 'archived'; // Hide archived products from listings
    });
  }, [products, category, subcategory, searchQuery]);

  // Extract filter parameters
  const filterOptions = useMemo(() => {
    const brands = new Set<string>();
    const sizes = new Set<string>();
    const colors = new Set<string>();
    let absoluteMaxPrice = 5000;

    contextProducts.forEach(p => {
      brands.add(p.brand);
      p.sizes.forEach(s => sizes.add(s.size));
      if (p.colors) p.colors.forEach(c => colors.add(c));
      if (p.price > absoluteMaxPrice) absoluteMaxPrice = p.price;
      if (p.discounted_price && p.discounted_price > absoluteMaxPrice) absoluteMaxPrice = p.discounted_price;
    });

    return {
      brands: Array.from(brands),
      sizes: Array.from(sizes),
      colors: Array.from(colors),
      absoluteMaxPrice
    };
  }, [contextProducts]);

  // Apply filters to context products
  const filteredProducts = useMemo(() => {
    let result = [...contextProducts];

    // Brand filter
    if (selectedBrands.length > 0) {
      result = result.filter(p => selectedBrands.includes(p.brand));
    }

    // Size filter
    if (selectedSizes.length > 0) {
      result = result.filter(p => 
        p.sizes.some(s => selectedSizes.includes(s.size) && s.stock > 0)
      );
    }

    // Color filter
    if (selectedColors.length > 0) {
      result = result.filter(p => 
        p.colors && p.colors.some(c => selectedColors.includes(c))
      );
    }

    // Availability filter
    if (selectedAvailability.length > 0) {
      result = result.filter(p => {
        const totalStock = p.sizes.reduce((sum, s) => sum + s.stock, 0);
        const isOutOfStock = totalStock === 0 || p.status === 'out-of-stock';
        
        if (selectedAvailability.includes('in-stock') && selectedAvailability.includes('out-of-stock')) {
          return true;
        }
        if (selectedAvailability.includes('in-stock')) {
          return !isOutOfStock;
        }
        if (selectedAvailability.includes('out-of-stock')) {
          return isOutOfStock;
        }
        return true;
      });
    }

    // Omnichannel mode filter (highly realistic signature UX!)
    if (shoppingMode === 'pickup') {
      result = result.filter(p => {
        const totalStock = p.sizes.reduce((sum, s) => sum + s.stock, 0);
        return totalStock > 0 && p.status === 'active';
      });
    }

    // Price filter
    result = result.filter(p => {
      const activePrice = p.discounted_price || p.price;
      return activePrice <= maxPrice;
    });

    // Sorting
    if (sortOption === 'price-low') {
      result.sort((a, b) => (a.discounted_price || a.price) - (b.discounted_price || b.price));
    } else if (sortOption === 'price-high') {
      result.sort((a, b) => (b.discounted_price || b.price) - (a.discounted_price || a.price));
    } else if (sortOption === 'new') {
      result.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
    } else {
      result.sort((a, b) => (b.is_featured ? 1 : 0) - (a.is_featured ? 1 : 0));
    }

    return result;
  }, [contextProducts, selectedBrands, selectedSizes, selectedColors, selectedAvailability, shoppingMode, maxPrice, sortOption]);

  const handleBrandToggle = (brand: string) => {
    setSelectedBrands(prev => 
      prev.includes(brand) ? prev.filter(b => b !== brand) : [...prev, brand]
    );
  };

  const handleSizeToggle = (size: string) => {
    setSelectedSizes(prev => 
      prev.includes(size) ? prev.filter(s => s !== size) : [...prev, size]
    );
  };

  const handleColorToggle = (color: string) => {
    setSelectedColors(prev => 
      prev.includes(color) ? prev.filter(c => c !== color) : [...prev, color]
    );
  };

  const handleAvailabilityToggle = (status: string) => {
    setSelectedAvailability(prev => 
      prev.includes(status) ? prev.filter(s => s !== status) : [...prev, status]
    );
  };

  const resetAllFilters = () => {
    setSelectedBrands([]);
    setSelectedSizes([]);
    setSelectedColors([]);
    setSelectedAvailability(['in-stock']);
    setShoppingMode('all');
    setMaxPrice(25000);
    setSortOption('featured');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 animate-fade-in bg-[#fafaf9] text-[#111111]" id="listing-view">
      
      {/* 1. BREADCRUMBS & SECTION TITLE */}
      <div className="border-b border-stone-200 pb-6 mb-8">
        <nav className="text-[9px] font-sans font-bold tracking-[0.2em] text-stone-400 uppercase flex gap-2 mb-3">
          <span>THE BRANDED HUB</span>
          <span>/</span>
          <span className="text-stone-800">{category}</span>
          {subcategory && (
            <>
              <span>/</span>
              <span className="text-stone-500 font-extrabold">{subcategory}</span>
            </>
          )}
        </nav>
        
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <h1 className="font-serif italic text-3xl sm:text-4xl font-light tracking-tight text-stone-900 flex items-center gap-2">
              {subcategory || category}
            </h1>
            <p className="text-[10px] text-stone-400 font-sans mt-2 tracking-widest font-semibold uppercase">
              RESERVAL DROP LIST • {filteredProducts.length} ITEMS AVAILABLE AT {selectedStore}
            </p>
          </div>
          
          {/* Top Sort Controls */}
          <div className="flex items-center gap-3 self-end sm:self-auto shrink-0 select-none">
            <span className="text-[9px] font-bold text-stone-400 uppercase tracking-widest">SORT BY:</span>
            <div className="relative">
              <select
                value={sortOption}
                onChange={(e) => setSortOption(e.target.value)}
                className="appearance-none bg-[#fafaf9] border border-stone-200 px-4 py-2 pr-10 text-[10px] font-bold uppercase tracking-widest text-stone-800 focus:outline-none focus:border-stone-400 cursor-pointer rounded-none"
                id="sort-select"
              >
                <option value="featured">Recommended Drops</option>
                <option value="price-low">Price: Low to High</option>
                <option value="price-high">Price: High to Low</option>
                <option value="new">Latest Releases</option>
              </select>
              <ChevronDown size={11} className="absolute right-3.5 top-1/2 -translate-y-1/2 text-stone-600 pointer-events-none" />
            </div>
          </div>
        </div>
      </div>

      {/* 2. MAIN GRID LAYOUT */}
      <div className="flex flex-col lg:flex-row gap-8 items-start">
        
        {/* Desktop Sidebar Filters */}
        <aside className="hidden lg:block w-60 shrink-0 bg-white border border-stone-200 p-5 rounded-none" id="desktop-filters">
          <div className="flex items-center justify-between border-b border-stone-100 pb-3 mb-5">
            <h2 className="font-sans text-[10px] font-extrabold uppercase text-stone-800 tracking-widest flex items-center gap-1.5">
              <Filter size={11} className="text-stone-600" /> REFINE DROP
            </h2>
            <button 
              onClick={resetAllFilters}
              className="text-[9px] font-sans tracking-widest text-stone-400 hover:text-stone-800 uppercase font-bold"
            >
              RESET
            </button>
          </div>

          <div className="space-y-6">
            
            {/* Shopping pickup/delivery toggle */}
            <div className="border-b border-stone-100 pb-4">
              <h3 className="text-[10px] font-bold text-stone-800 uppercase tracking-widest mb-3 flex items-center gap-1">
                <MapPin size={11} className="text-stone-600" /> SHOWROOM LOGISTICS
              </h3>
              <div className="space-y-1.5 text-[11px]">
                <button
                  onClick={() => setShoppingMode('all')}
                  className={`w-full text-left px-2.5 py-2 border transition-colors flex justify-between items-center ${shoppingMode === 'all' ? 'border-stone-800 bg-[#ece8e1] text-stone-900 font-bold' : 'border-stone-100 hover:bg-stone-50 text-stone-600'}`}
                >
                  <span>All Stock Modes</span>
                  <Check size={11} className={shoppingMode === 'all' ? 'opacity-100' : 'opacity-0'} />
                </button>
                
                <button
                  onClick={() => setShoppingMode('pickup')}
                  className={`w-full text-left p-2.5 border transition-colors flex flex-col ${shoppingMode === 'pickup' ? 'border-stone-800 bg-[#ece8e1] text-stone-900 font-bold' : 'border-stone-100 hover:bg-stone-50 text-stone-600'}`}
                >
                  <div className="flex justify-between items-center w-full">
                    <span className="font-bold">In-Store Pickup</span>
                    <Check size={11} className={shoppingMode === 'pickup' ? 'opacity-100' : 'opacity-0'} />
                  </div>
                  <span className="text-[9px] text-stone-400 font-normal mt-0.5 uppercase tracking-tight">2h Collection at {selectedStore}</span>
                </button>
              </div>
            </div>

            {/* Availability */}
            <div className="border-b border-stone-100 pb-4">
              <h3 className="text-[10px] font-bold text-stone-800 uppercase tracking-widest mb-3">AVAILABILITY</h3>
              <div className="space-y-2">
                {['in-stock', 'out-of-stock'].map(status => (
                  <label key={status} className="flex items-center gap-2.5 text-xs text-stone-600 cursor-pointer select-none">
                    <input 
                      type="checkbox"
                      checked={selectedAvailability.includes(status)}
                      onChange={() => handleAvailabilityToggle(status)}
                      className="rounded-none border-stone-300 text-stone-800 focus:ring-stone-400"
                    />
                    <span className="capitalize font-semibold text-stone-700">{status === 'in-stock' ? 'In Stock Now' : 'Show Sold Out'}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Brands */}
            {filterOptions.brands.length > 0 && (
              <div className="border-b border-stone-100 pb-4">
                <h3 className="text-[10px] font-bold text-stone-800 uppercase tracking-widest mb-3">BRANDS</h3>
                <div className="space-y-2 max-h-40 overflow-y-auto pr-1">
                  {filterOptions.brands.map(brand => (
                    <label key={brand} className="flex items-center gap-2.5 text-xs text-stone-600 cursor-pointer select-none">
                      <input 
                        type="checkbox"
                        checked={selectedBrands.includes(brand)}
                        onChange={() => handleBrandToggle(brand)}
                        className="rounded-none border-stone-300 text-stone-800 focus:ring-stone-400"
                      />
                      <span className="font-semibold text-stone-700">{brand}</span>
                    </label>
                  ))}
                </div>
              </div>
            )}

            {/* Price range budget slider */}
            <div className="border-b border-stone-100 pb-4">
              <div className="flex justify-between items-center mb-3">
                <h3 className="text-[10px] font-bold text-stone-800 uppercase tracking-widest">BUDGET</h3>
                <span className="text-[11px] font-mono font-bold text-stone-900">₹{maxPrice.toLocaleString('en-IN')}</span>
              </div>
              <input 
                type="range"
                min="500"
                max="25000"
                step="500"
                value={maxPrice}
                onChange={(e) => setMaxPrice(parseInt(e.target.value))}
                className="w-full h-1 bg-stone-200 rounded-none appearance-none cursor-pointer accent-stone-800"
              />
              <div className="flex justify-between text-[8px] font-mono text-stone-400 mt-1 uppercase tracking-wider">
                <span>₹500</span>
                <span>₹25,000</span>
              </div>
            </div>

            {/* Sizes */}
            {filterOptions.sizes.length > 0 && (
              <div className="border-b border-stone-100 pb-4">
                <h3 className="text-[10px] font-bold text-stone-800 uppercase tracking-widest mb-3">SIZES</h3>
                <div className="grid grid-cols-4 gap-1">
                  {filterOptions.sizes.map(size => {
                    const isSelected = selectedSizes.includes(size);
                    return (
                      <button
                        key={size}
                        onClick={() => handleSizeToggle(size)}
                        className={`text-[9px] font-mono font-bold py-2 text-center transition-colors border ${
                          isSelected 
                            ? 'bg-black border-black text-[#fafaf9] font-black' 
                            : 'bg-white border-stone-200 text-stone-600 hover:border-stone-400'
                        }`}
                      >
                        {size}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Colors */}
            {filterOptions.colors.length > 0 && (
              <div>
                <h3 className="text-[10px] font-bold text-stone-800 uppercase tracking-widest mb-3">COLORS</h3>
                <div className="flex flex-wrap gap-1">
                  {filterOptions.colors.map(color => {
                    const isSelected = selectedColors.includes(color);
                    return (
                      <button
                        key={color}
                        onClick={() => handleColorToggle(color)}
                        className={`text-[9px] font-bold px-2 py-1.5 rounded-none transition-colors border uppercase tracking-wider ${
                          isSelected 
                            ? 'bg-black border-black text-[#fafaf9]' 
                            : 'bg-white border-stone-200 text-stone-600 hover:border-stone-400'
                        }`}
                      >
                        {color}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        </aside>

        {/* Product Catalog Grid */}
        <div className="w-full">
          
          {/* Mobile Filter Button */}
          <div className="lg:hidden w-full flex gap-2.5 mb-6">
            <button
              onClick={() => setMobileFiltersOpen(true)}
              className="w-full flex items-center justify-center gap-2 bg-black text-white font-sans text-xs font-black uppercase tracking-widest py-3.5"
              id="mobile-filter-trigger"
            >
              <SlidersHorizontal size={12} /> FILTER DROPS ({filteredProducts.length})
            </button>
            {(selectedBrands.length > 0 || selectedSizes.length > 0 || selectedColors.length > 0 || maxPrice < 25000 || selectedAvailability.length !== 1 || shoppingMode !== 'all') && (
              <button
                onClick={resetAllFilters}
                className="border border-black text-black text-xs font-bold uppercase tracking-widest px-4"
              >
                Reset
              </button>
            )}
          </div>

          {/* Active filter badges */}
          <div className="flex flex-wrap gap-1.5 mb-6">
            {shoppingMode !== 'all' && (
              <span className="inline-flex items-center gap-1.5 bg-[#ece8e1] text-stone-800 text-[9px] font-bold pl-2.5 pr-1.5 py-1 rounded-none border border-stone-300 uppercase tracking-widest">
                Pickup Mode: Jayanagar/BTM 
                <X size={10} className="cursor-pointer text-stone-400 hover:text-stone-900" onClick={() => setShoppingMode('all')} />
              </span>
            )}
            {selectedBrands.map(b => (
              <span key={b} className="inline-flex items-center gap-1.5 bg-stone-100 text-stone-800 text-[9px] font-bold pl-2.5 pr-1.5 py-1 rounded-none border border-stone-200 uppercase tracking-widest">
                {b} <X size={10} className="cursor-pointer text-stone-400 hover:text-stone-900" onClick={() => handleBrandToggle(b)} />
              </span>
            ))}
            {selectedSizes.map(s => (
              <span key={s} className="inline-flex items-center gap-1.5 bg-stone-100 text-stone-800 text-[9px] font-bold pl-2.5 pr-1.5 py-1 rounded-none border border-stone-200 uppercase tracking-widest">
                Size: {s} <X size={10} className="cursor-pointer text-stone-400 hover:text-stone-900" onClick={() => handleSizeToggle(s)} />
              </span>
            ))}
            {selectedColors.map(c => (
              <span key={c} className="inline-flex items-center gap-1.5 bg-stone-100 text-stone-800 text-[9px] font-bold pl-2.5 pr-1.5 py-1 rounded-none border border-stone-200 uppercase tracking-widest">
                Color: {c} <X size={10} className="cursor-pointer text-stone-400 hover:text-stone-900" onClick={() => handleColorToggle(c)} />
              </span>
            ))}
            {maxPrice < 25000 && (
              <span className="inline-flex items-center gap-1.5 bg-stone-100 text-stone-800 text-[9px] font-bold pl-2.5 pr-1.5 py-1 rounded-none border border-stone-200 uppercase tracking-widest">
                &lt; ₹{maxPrice.toLocaleString('en-IN')} <X size={10} className="cursor-pointer text-stone-400 hover:text-stone-900" onClick={() => setMaxPrice(25000)} />
              </span>
            )}
          </div>

          {/* Catalog Listing Grid */}
          {filteredProducts.length === 0 ? (
            <div className="bg-white border border-stone-200 py-16 text-center px-4 max-w-md mx-auto mt-6">
              <span className="text-2xl block mb-3">🔍</span>
              <h3 className="font-serif italic text-sm text-stone-800 mb-2">No streetwear drops match</h3>
              <p className="text-stone-500 text-[11px] leading-relaxed mb-6 font-medium">
                Try choosing another store showroom or resetting selected filter categories to view stock.
              </p>
              <button
                onClick={resetAllFilters}
                className="bg-black hover:bg-stone-800 text-[#fafaf9] text-[10px] font-bold uppercase tracking-widest px-6 py-3.5"
              >
                Reset All Filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 gap-x-4 gap-y-10 sm:gap-x-6 sm:gap-y-12 animate-fade-in">
              {filteredProducts.map(product => {
                const totalStock = product.sizes.reduce((sum, s) => sum + s.stock, 0);
                const isOutOfStock = totalStock === 0 || product.status === 'out-of-stock';
                const discountPercent = product.discounted_price 
                  ? Math.round(((product.price - product.discounted_price) / product.price) * 100) 
                  : 0;

                return (
                  <div
                    key={product.id}
                    onClick={() => onSelectProduct(product.slug)}
                    className="cursor-pointer group flex flex-col"
                  >
                    <div className="relative aspect-[3/4] bg-[#f2ede4]/40 border border-stone-200/40 overflow-hidden mb-4 shrink-0">
                      {isOutOfStock ? (
                        <span className="absolute top-3 left-3 bg-[#1a1a1a] text-[#fafaf9] text-[8px] font-bold tracking-widest uppercase px-2 py-0.5 z-10">
                          SOLD OUT
                        </span>
                      ) : discountPercent > 0 ? (
                        <span className="absolute top-3 left-3 bg-black text-white text-[8px] font-extrabold tracking-widest uppercase px-2 py-0.5 z-10">
                          {discountPercent}% OFF
                        </span>
                      ) : null}

                      {!isOutOfStock && totalStock > 0 && totalStock <= 4 && (
                        <span className="absolute bottom-3 left-3 bg-[#ece8e1] text-[#111111] border border-stone-300 text-[8px] font-bold tracking-widest uppercase px-1.5 py-0.5 z-10">
                          ONLY {totalStock} LEFT
                        </span>
                      )}

                      <img
                        src={product.images[0]}
                        alt={product.name}
                        className="w-full h-full object-cover object-center transform group-hover:scale-102 transition-transform duration-500"
                        loading="lazy"
                      />

                      <div className="absolute inset-0 bg-black/5 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity z-10">
                        <span className="bg-white text-black text-[9px] font-bold tracking-[0.25em] uppercase px-5 py-3 shadow-sm border border-stone-200">
                          SELECT SIZE
                        </span>
                      </div>
                    </div>

                    <div className="text-center space-y-1">
                      <span className="text-[9px] font-bold text-stone-400 tracking-widest uppercase block">
                        {product.brand}
                      </span>
                      <h3 className="text-[11px] font-semibold text-stone-800 tracking-wide hover:text-stone-500 transition-colors uppercase truncate max-w-full px-1">
                        {product.name}
                      </h3>
                      
                      {/* Price layout */}
                      <div className="flex items-center justify-center gap-2 text-[10px] font-mono tracking-wider font-semibold">
                        {product.discounted_price ? (
                          <>
                            <span className="text-stone-900">
                              ₹{product.discounted_price.toLocaleString('en-IN')}
                            </span>
                            <span className="text-stone-400 line-through">
                              ₹{product.price.toLocaleString('en-IN')}
                            </span>
                          </>
                        ) : (
                          <span className="text-stone-800">
                            ₹{product.price.toLocaleString('en-IN')}
                          </span>
                        )}
                      </div>

                      {/* Display sizes below, just like the image */}
                      <div className="pt-1.5 text-[8px] font-bold text-stone-400 uppercase tracking-widest flex justify-center gap-1.5 select-none">
                        {product.sizes.map((s, idx) => (
                          <span key={idx} className={s.stock > 0 ? 'text-stone-600' : 'text-stone-300 line-through'}>
                            {s.size}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Mobile Drawer Filter Modal */}
      {mobileFiltersOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex" id="mobile-filter-drawer">
          <div 
            className="absolute inset-0 bg-black/40 transition-opacity"
            onClick={() => setMobileFiltersOpen(false)}
          />

          <div className="relative ml-auto w-full max-w-xs h-full bg-[#fafaf9] shadow-2xl flex flex-col animate-slide-left z-10">
            {/* Header */}
            <div className="flex items-center justify-between px-5 py-4 border-b border-stone-200 bg-white">
              <h2 className="font-sans text-[10px] font-extrabold text-stone-800 uppercase tracking-widest flex items-center gap-1.5">
                <Filter size={12} className="text-stone-600" /> FILTER CATALOG
              </h2>
              <button 
                onClick={() => setMobileFiltersOpen(false)}
                className="p-1.5 text-stone-600"
              >
                <X size={18} />
              </button>
            </div>

            {/* Body */}
            <div className="flex-1 overflow-y-auto px-5 py-6 space-y-6">
              <div>
                <h3 className="text-[10px] font-bold text-stone-800 uppercase tracking-widest mb-3">Shopping Preference</h3>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => setShoppingMode('all')}
                    className={`text-[9px] font-bold py-2 border text-center uppercase tracking-wider ${shoppingMode === 'all' ? 'border-black bg-[#ece8e1] text-black' : 'border-stone-200 text-stone-600'}`}
                  >
                    All Modes
                  </button>
                  <button
                    onClick={() => setShoppingMode('pickup')}
                    className={`text-[9px] font-bold py-2 border text-center uppercase tracking-wider ${shoppingMode === 'pickup' ? 'border-black bg-[#ece8e1] text-black' : 'border-stone-200 text-stone-600'}`}
                  >
                    Store Pickup
                  </button>
                </div>
              </div>

              <div>
                <h3 className="text-[10px] font-bold text-stone-800 uppercase tracking-widest mb-3">Availability</h3>
                <div className="space-y-2">
                  {['in-stock', 'out-of-stock'].map(status => (
                    <label key={status} className="flex items-center gap-2.5 text-xs text-stone-600 cursor-pointer select-none">
                      <input 
                        type="checkbox"
                        checked={selectedAvailability.includes(status)}
                        onChange={() => handleAvailabilityToggle(status)}
                        className="rounded-none border-stone-300 text-stone-800 focus:ring-stone-400"
                      />
                      <span className="capitalize font-semibold text-stone-700">{status === 'in-stock' ? 'In Stock' : 'Show Sold Out'}</span>
                    </label>
                  ))}
                </div>
              </div>

              {filterOptions.brands.length > 0 && (
                <div>
                  <h3 className="text-[10px] font-bold text-stone-800 uppercase tracking-widest mb-3">Brands</h3>
                  <div className="space-y-2">
                    {filterOptions.brands.map(brand => (
                      <label key={brand} className="flex items-center gap-2.5 text-xs text-stone-600 cursor-pointer select-none">
                        <input 
                          type="checkbox"
                          checked={selectedBrands.includes(brand)}
                          onChange={() => handleBrandToggle(brand)}
                          className="rounded-none border-stone-300 text-stone-800 focus:ring-stone-400"
                        />
                        <span className="font-semibold text-stone-700">{brand}</span>
                      </label>
                    ))}
                  </div>
                </div>
              )}

              <div>
                <div className="flex justify-between items-center mb-3">
                  <h3 className="text-[10px] font-bold text-stone-800 uppercase tracking-widest">Max Budget</h3>
                  <span className="text-xs font-mono font-bold text-stone-900">₹{maxPrice.toLocaleString('en-IN')}</span>
                </div>
                <input 
                  type="range"
                  min="500"
                  max="25000"
                  step="500"
                  value={maxPrice}
                  onChange={(e) => setMaxPrice(parseInt(e.target.value))}
                  className="w-full h-1 bg-stone-200 rounded-none appearance-none cursor-pointer accent-stone-800"
                />
              </div>

              {filterOptions.sizes.length > 0 && (
                <div>
                  <h3 className="text-[10px] font-bold text-stone-800 uppercase tracking-widest mb-3">Sizes</h3>
                  <div className="flex flex-wrap gap-1">
                    {filterOptions.sizes.map(size => {
                      const isSelected = selectedSizes.includes(size);
                      return (
                        <button
                          key={size}
                          onClick={() => handleSizeToggle(size)}
                          className={`text-[9px] font-mono font-bold px-3 py-2 border ${
                            isSelected 
                              ? 'bg-black border-black text-[#fafaf9]' 
                              : 'bg-white border-stone-200 text-stone-600'
                          }`}
                        >
                          {size}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>

            {/* Bottom Actions */}
            <div className="p-4 border-t border-stone-200 bg-white flex gap-3">
              <button
                onClick={resetAllFilters}
                className="flex-1 border border-stone-200 text-stone-600 text-[10px] font-bold uppercase py-3.5"
              >
                Reset
              </button>
              <button
                onClick={() => setMobileFiltersOpen(false)}
                className="flex-1 bg-black text-[#fafaf9] text-[10px] font-bold uppercase py-3.5"
              >
                Apply
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
