import React, { useState, useMemo, useEffect } from 'react';
import { Product } from '../types';
import { ShoppingBag, ChevronRight, Share2, HelpCircle, Check, Sparkles, MessageSquare, Star, MapPin, Truck, Award } from 'lucide-react';

interface PdpViewProps {
  product: Product;
  onAddToCart: (p: Product, size: string, qty: number) => void;
  relatedProducts: Product[];
  onSelectProduct: (slug: string) => void;
  onLogInquiry: (customerName: string, customerPhone: string, selectedSize: string, qty: number) => void;
}

export default function PdpView({
  product,
  onAddToCart,
  relatedProducts,
  onSelectProduct,
  onLogInquiry,
}: PdpViewProps) {
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [selectedSize, setSelectedSize] = useState<string>('');
  const [quantity, setQuantity] = useState<number>(1);
  const [showShareTooltip, setShowShareTooltip] = useState(false);

  // Real-time store selection sync
  const [selectedStore, setSelectedStore] = useState(() => {
    return localStorage.getItem('tbh_selected_store') || 'Jayanagar 3rd Block';
  });

  useEffect(() => {
    const handleStoreChange = () => {
      setSelectedStore(localStorage.getItem('tbh_selected_store') || 'Jayanagar 3rd Block');
    };
    window.addEventListener('store-changed', handleStoreChange);
    return () => window.removeEventListener('store-changed', handleStoreChange);
  }, []);

  // For the custom WhatsApp Checkout Prompt
  const [showCheckoutPrompt, setShowCheckoutPrompt] = useState(false);
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [formError, setFormError] = useState('');

  // Total calculated stock
  const totalStock = useMemo(() => {
    return product.sizes.reduce((sum, s) => sum + s.stock, 0);
  }, [product]);

  // Selected size stock
  const selectedSizeStock = useMemo(() => {
    if (!selectedSize) return null;
    const match = product.sizes.find(s => s.size === selectedSize);
    return match ? match.stock : 0;
  }, [selectedSize, product]);

  const discountPercent = useMemo(() => {
    if (!product.discounted_price) return 0;
    return Math.round(((product.price - product.discounted_price) / product.price) * 100);
  }, [product]);

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    setShowShareTooltip(true);
    setTimeout(() => setShowShareTooltip(false), 2000);
  };

  const handleWhatsAppCheckoutInitiate = () => {
    if (!selectedSize) {
      alert("Please select your size first to secure this drop!");
      return;
    }
    setShowCheckoutPrompt(true);
  };

  const executeWhatsAppCheckout = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName || !customerPhone) {
      setFormError("Name and Phone number are required to connect your order.");
      return;
    }
    if (customerPhone.length < 10) {
      setFormError("Please enter a valid 10-digit mobile number.");
      return;
    }

    setFormError('');
    setShowCheckoutPrompt(false);

    // 1. Log the inquiry in our Admin database
    onLogInquiry(customerName, customerPhone, selectedSize, quantity);

    // 2. Generate WhatsApp wa.me redirect
    const activePrice = product.discounted_price || product.price;
    const finalPrice = activePrice * quantity;
    const currentUrl = window.location.href;

    const message = `Hello The Branded Hub Bangalore! 🏬✨
    
I would like to order:
*Product:* ${product.brand} - ${product.name}
*Size:* ${selectedSize}
*Quantity:* ${quantity}
*Store Pick:* ${selectedStore}
*Total Price:* ₹${finalPrice.toLocaleString('en-IN')}

*My Details:*
- Name: ${customerName}
- Phone: ${customerPhone}

*Product Link:* ${currentUrl}

Please reserve my size and share payment/pickup details. Thank you!`;

    // Open WhatsApp
    const waUrl = `https://wa.me/9187718184915?text=${encodeURIComponent(message)}`;
    window.open(waUrl, '_blank');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 animate-fade-in bg-[#fafaf9] text-[#111111]" id="pdp-view">
      
      {/* 1. BREADCRUMBS */}
      <nav className="text-[9px] font-sans font-bold tracking-[0.2em] text-stone-400 uppercase flex items-center gap-2 mb-8">
        <span>THE BRANDED HUB CATALOG</span>
        <ChevronRight size={10} className="text-stone-300" />
        <span className="cursor-pointer hover:text-stone-800 uppercase">{product.category}</span>
        <ChevronRight size={10} className="text-stone-300" />
        <span className="text-stone-800 uppercase font-extrabold">{product.subcategory}</span>
      </nav>

      {/* 2. PRODUCT CONTENT GRID */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start mb-16">
        
        {/* Left: Image Gallery */}
        <div className="lg:col-span-7 flex flex-col md:flex-row gap-4">
          
          {/* Thumbnails */}
          <div className="flex md:flex-col gap-2 order-2 md:order-1 overflow-x-auto md:overflow-x-visible pb-2 md:pb-0 shrink-0">
            {product.images.map((img, idx) => (
              <button
                key={idx}
                onMouseEnter={() => setActiveImageIndex(idx)}
                onClick={() => setActiveImageIndex(idx)}
                className={`w-16 h-20 sm:w-20 sm:h-24 rounded-none border overflow-hidden shrink-0 transition-all ${
                  idx === activeImageIndex ? 'border-black' : 'border-stone-200 hover:border-stone-400'
                }`}
                id={`pdp-thumb-${idx}`}
              >
                <img src={img} alt={`${product.name} thumb ${idx}`} className="w-full h-full object-cover object-center" />
              </button>
            ))}
          </div>

          {/* Main Frame */}
          <div className="relative flex-1 order-1 md:order-2 aspect-[3/4] rounded-none border border-stone-200 overflow-hidden bg-[#f2ede4]/30" id="pdp-hero-image">
            {discountPercent > 0 && (
              <span className="absolute top-4 left-4 bg-black text-[#fafaf9] text-[9px] font-bold tracking-widest uppercase px-3 py-1">
                {discountPercent}% OFF TODAY
              </span>
            )}
            <img 
              src={product.images[activeImageIndex]} 
              alt={product.name} 
              className="w-full h-full object-cover object-center"
            />
          </div>
        </div>

        {/* Right Column: Checkout Info Block */}
        <div className="lg:col-span-5 bg-white p-6 sm:p-8 border border-stone-200" id="pdp-content-panel">
          
          {/* Brand & Name */}
          <div className="space-y-2">
            <span className="text-[9px] font-extrabold text-stone-400 tracking-[0.25em] uppercase block font-sans">
              LIMITED {product.brand} RELEASE
            </span>
            <h1 className="font-serif italic text-2xl sm:text-3xl font-light text-stone-900 leading-tight">
              {product.name}
            </h1>
            
            {/* Stars & Reviews */}
            <div className="flex items-center gap-2 pt-1">
              <div className="flex text-stone-800">
                <Star size={11} fill="currentColor" />
                <Star size={11} fill="currentColor" />
                <Star size={11} fill="currentColor" />
                <Star size={11} fill="currentColor" />
                <Star size={11} fill="currentColor" />
              </div>
              <span className="text-[10px] text-stone-400 font-bold uppercase tracking-widest">
                4.9/5 • verified buyers
              </span>
            </div>
          </div>

          {/* Pricing Box */}
          <div className="border-t border-b border-stone-100 py-5 my-6 space-y-3">
            <div className="flex items-baseline gap-3">
              {product.discounted_price ? (
                <>
                  <span className="text-2xl font-mono font-bold text-stone-900">
                    ₹{product.discounted_price.toLocaleString('en-IN')}
                  </span>
                  <span className="text-sm text-stone-400 line-through font-mono">
                    ₹{product.price.toLocaleString('en-IN')}
                  </span>
                  <span className="bg-[#ece8e1] text-stone-800 text-[8px] font-extrabold tracking-widest uppercase px-2 py-0.5 border border-stone-300">
                    SAVE {discountPercent}%
                  </span>
                </>
              ) : (
                <span className="text-2xl font-mono font-bold text-stone-900">
                  ₹{product.price.toLocaleString('en-IN')}
                </span>
              )}
            </div>
            
            <div className="bg-[#fafaf9] p-3 text-[10px] font-semibold text-stone-500 uppercase tracking-wider leading-relaxed border-l-2 border-stone-400">
              ⚡ COMPLIMENTARY OFFERS: Spend ₹1,500 to automatically credit ₹500 directly off checkout value!
            </div>
          </div>

          {/* Size Selector */}
          <div className="mb-6">
            <div className="flex justify-between items-center mb-3">
              <span className="text-[10px] font-bold text-stone-800 uppercase tracking-widest">SELECT SIZE:</span>
              <button 
                onClick={() => alert("Tailored regular to relaxed fit. Buy your exact regular standard size.")}
                className="text-[9px] font-sans font-bold text-stone-400 hover:text-stone-800 flex items-center gap-1 uppercase tracking-widest hover:underline"
              >
                <HelpCircle size={11} /> Size Guide
              </button>
            </div>

            <div className="flex flex-wrap gap-2" id="pdp-size-selector">
              {product.sizes.map(sz => {
                const isOutOfStock = sz.stock === 0;
                const isSelected = selectedSize === sz.size;

                return (
                  <button
                    key={sz.size}
                    disabled={isOutOfStock}
                    onClick={() => {
                      setSelectedSize(sz.size);
                      setQuantity(1);
                    }}
                    className={`relative text-[11px] font-mono font-bold px-4 py-3 min-w-12 rounded-none border transition-all flex flex-col items-center justify-center ${
                      isOutOfStock
                        ? 'bg-stone-100 border-stone-200 text-stone-300 cursor-not-allowed line-through'
                        : isSelected
                        ? 'bg-black border-black text-white font-black'
                        : 'bg-white border-stone-200 text-stone-800 hover:border-black'
                    }`}
                  >
                    <span>{sz.size}</span>
                    {sz.stock > 0 && sz.stock <= 3 && (
                      <span className="text-[6.5px] font-sans text-stone-500 font-bold absolute bottom-0.5 leading-none">
                        {sz.stock} LEFT
                      </span>
                    )}
                  </button>
                );
              })}
            </div>

            {/* Selected size specific alerts */}
            {selectedSize && selectedSizeStock !== null && (
              <div className="mt-3 text-[9px] font-bold tracking-widest uppercase text-stone-500">
                {selectedSizeStock === 0 ? (
                  <span className="text-stone-400">❌ Out of stock in preferred size.</span>
                ) : selectedSizeStock <= 3 ? (
                  <span className="text-stone-800">⚠️ Limited: Only {selectedSizeStock} left!</span>
                ) : (
                  <span className="text-stone-600">✓ In-stock & ready for pickup from {selectedStore}</span>
                )}
              </div>
            )}
          </div>

          {/* Quantity Selector */}
          {selectedSize && selectedSizeStock && selectedSizeStock > 0 ? (
            <div className="flex items-center gap-4 mb-6 select-none">
              <span className="text-[10px] font-bold text-stone-800 uppercase tracking-widest">QUANTITY:</span>
              <div className="flex items-center border border-stone-200 bg-white">
                <button
                  onClick={() => setQuantity(prev => Math.max(1, prev - 1))}
                  className="px-3 py-1.5 hover:bg-stone-100 text-stone-700 font-bold font-mono text-[11px]"
                >
                  -
                </button>
                <span className="px-4 py-1.5 text-[11px] font-bold font-mono text-stone-900 bg-[#fafaf9]">
                  {quantity}
                </span>
                <button
                  onClick={() => setQuantity(prev => Math.min(selectedSizeStock || 1, prev + 1))}
                  className="px-3 py-1.5 hover:bg-stone-100 text-stone-700 font-bold font-mono text-[11px]"
                >
                  +
                </button>
              </div>
            </div>
          ) : null}

          {/* LOGISTICS CARD INFO */}
          <div className="bg-[#fafaf9] p-4 border border-stone-200 mb-6 space-y-3 text-[11px] text-stone-600">
            <div className="flex items-start gap-2.5">
              <MapPin size={14} className="text-stone-600 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-stone-900 uppercase block text-[9px] tracking-wider">Free Pickup In-Store</span>
                <span className="text-stone-500 block text-[10px] mt-0.5 uppercase tracking-wide">
                  Ready within 2 hours at Jayanagar or BTM showrooms
                </span>
              </div>
            </div>
            
            <div className="flex items-start gap-2.5 border-t border-stone-100 pt-2.5">
              <Truck size={14} className="text-stone-600 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-stone-900 uppercase block text-[9px] tracking-wider">Complimentary Home Delivery</span>
                <span className="text-stone-500 block text-[10px] mt-0.5 uppercase tracking-wide">
                  Free shipping inside Bangalore on orders above ₹1,999
                </span>
              </div>
            </div>
          </div>

          {/* Checkout Actions */}
          <div className="space-y-2.5">
            {totalStock === 0 || product.status === 'out-of-stock' ? (
              <div className="w-full bg-stone-100 text-stone-400 font-sans text-[10px] font-bold uppercase tracking-widest text-center py-4 border border-stone-200">
                SOLD OUT
              </div>
            ) : (
              <>
                {/* Buy on WhatsApp */}
                <button
                  onClick={handleWhatsAppCheckoutInitiate}
                  className="w-full bg-black hover:bg-stone-800 text-white font-sans text-[10px] font-bold uppercase tracking-widest py-4 transition-colors flex items-center justify-center gap-2"
                  id="pdp-buy-whatsapp"
                >
                  <MessageSquare size={13} className="fill-white text-white" /> SECURE DEAL VIA WHATSAPP
                </button>

                {/* Add to Shopping Bag */}
                <button
                  onClick={() => {
                    if (!selectedSize) {
                      alert("Please select your size first to secure this drop!");
                      return;
                    }
                    onAddToCart(product, selectedSize, quantity);
                  }}
                  className="w-full border border-stone-200 bg-white text-stone-800 hover:border-black font-sans text-[10px] font-bold uppercase tracking-widest py-3.5 transition-all flex items-center justify-center gap-2"
                  id="pdp-add-bag"
                >
                  <ShoppingBag size={13} /> ADD TO SHOPPING BAG
                </button>
              </>
            )}
          </div>

          {/* Details list */}
          <div className="space-y-4 text-[11px] leading-relaxed text-stone-500 font-sans mt-8 pt-6 border-t border-stone-150">
            <div>
              <h3 className="font-bold text-stone-800 uppercase tracking-widest mb-1 text-[9px]">Description</h3>
              <p className="font-medium">{product.description}</p>
            </div>
            
            <div>
              <h3 className="font-bold text-stone-800 uppercase tracking-widest mb-1 text-[9px]">Specifications</h3>
              <ul className="list-disc pl-4 space-y-1 font-medium">
                <li>Heavyweight 240 GSM pre-shrunk cotton loopback fibers</li>
                <li>Pristine flatlock stitching for visual premium durability</li>
                <li>Ethically certified manufacturing drop</li>
                <li>Immediate physical inspection/returns available at showroom</li>
              </ul>
            </div>
          </div>

        </div>
      </div>

      {/* 3. RELATED PRODUCTS */}
      {relatedProducts.length > 0 && (
        <section className="border-t border-stone-200 pt-16">
          <div className="text-center mb-10">
            <span className="text-stone-400 text-[9px] font-bold tracking-[0.25em] uppercase block mb-1">COMPLEMENT THE SILHOUETTE</span>
            <h2 className="text-xs sm:text-sm font-extrabold tracking-[0.2em] uppercase text-stone-900">
              CUSTOMERS ALSO BOUGHT
            </h2>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
            {relatedProducts.map(rel => {
              const relDiscount = rel.discounted_price 
                ? Math.round(((rel.price - rel.discounted_price) / rel.price) * 100) 
                : 0;

              return (
                <div
                  key={rel.id}
                  onClick={() => {
                    onSelectProduct(rel.slug);
                    setSelectedSize('');
                    setQuantity(1);
                    setActiveImageIndex(0);
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="cursor-pointer group flex flex-col"
                >
                  <div className="relative aspect-[3/4] bg-[#f2ede4]/40 border border-stone-200/40 overflow-hidden mb-4">
                    {relDiscount > 0 && (
                      <span className="absolute top-3 left-3 bg-black text-[#fafaf9] text-[8px] font-bold tracking-widest uppercase px-2 py-0.5 z-10">
                        {relDiscount}% OFF
                      </span>
                    )}
                    <img
                      src={rel.images[0]}
                      alt={rel.name}
                      className="w-full h-full object-cover object-center transform group-hover:scale-102 transition-transform duration-500"
                    />
                  </div>
                  <div className="text-center space-y-1">
                    <span className="text-[9px] font-bold text-stone-400 tracking-widest uppercase block">{rel.brand}</span>
                    <h3 className="text-[11px] font-semibold text-stone-850 truncate uppercase group-hover:text-stone-500 transition-colors tracking-wide">{rel.name}</h3>
                    <div className="flex items-center justify-center gap-2 text-[10px] font-mono tracking-wider font-semibold">
                      {rel.discounted_price ? (
                        <>
                          <span className="text-stone-900">
                            ₹{rel.discounted_price.toLocaleString('en-IN')}
                          </span>
                          <span className="text-stone-400 line-through">
                            ₹{rel.price.toLocaleString('en-IN')}
                          </span>
                        </>
                      ) : (
                        <span className="text-stone-800 font-semibold">
                          ₹{rel.price.toLocaleString('en-IN')}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* WhatsApp Booking Customer Details Form */}
      {showCheckoutPrompt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div 
            className="absolute inset-0 bg-black/40 transition-opacity"
            onClick={() => setShowCheckoutPrompt(false)}
          />

          <div className="relative bg-white border border-stone-200 rounded-none shadow-2xl p-6 sm:p-8 w-full max-w-md z-10 animate-fade-in">
            <h3 className="font-serif italic text-lg text-stone-900 mb-2">
              Secure Showroom Reserve
            </h3>
            <p className="text-[11px] text-stone-500 leading-relaxed mb-6 font-sans">
              Provide your details to register this reserve request on the hub registry, and connect instantly to WhatsApp for showroom pickup or home delivery!
            </p>

            <form onSubmit={executeWhatsAppCheckout} className="space-y-4">
              {formError && (
                <div className="bg-stone-50 border border-stone-200 text-stone-600 text-xs px-3 py-2 rounded-none font-sans">
                  {formError}
                </div>
              )}

              <div>
                <label className="block text-[9px] font-bold text-stone-400 tracking-widest uppercase mb-1">YOUR FULL NAME</label>
                <input 
                  type="text"
                  placeholder="Virat Kohli"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="w-full border border-stone-200 rounded-none px-3.5 py-2.5 text-xs focus:outline-none focus:border-stone-800 font-sans"
                  required
                />
              </div>

              <div>
                <label className="block text-[9px] font-bold text-stone-400 tracking-widest uppercase mb-1">WHATSAPP MOBILE NUMBER</label>
                <div className="relative flex">
                  <span className="inline-flex items-center px-3.5 rounded-none border border-r-0 border-stone-200 bg-stone-50 text-stone-500 text-[11px] font-mono">
                    +91
                  </span>
                  <input 
                    type="tel"
                    placeholder="9876543210"
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value.replace(/\D/g, '').slice(0, 10))}
                    className="w-full border border-stone-200 rounded-none px-3.5 py-2.5 text-xs focus:outline-none focus:border-stone-800 font-mono"
                    required
                  />
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowCheckoutPrompt(false)}
                  className="flex-1 border border-stone-200 hover:bg-stone-50 text-stone-600 text-[10px] font-bold uppercase py-3.5"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-black text-[#fafaf9] text-[10px] font-bold uppercase py-3.5"
                >
                  PROCEED TO BOOKING
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
