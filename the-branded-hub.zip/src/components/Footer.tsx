import React from 'react';
import { MapPin, Phone, Mail, Clock, Instagram, Facebook, Award, ShieldCheck } from 'lucide-react';

interface FooterProps {
  onNavigatePage: (page: string, sub: string | null) => void;
}

export default function Footer({ onNavigatePage }: FooterProps) {
  const currentYear = new Date().getFullYear();

  const handleLinkClick = (page: string, sub: string | null = null) => {
    onNavigatePage(page, sub);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#111111] text-stone-300 font-sans text-xs border-t border-stone-800" id="site-footer">
      
      {/* Upper Complimentary Ribbon */}
      <div className="bg-[#ece8e1] text-stone-900 py-3.5 px-4 border-b border-stone-200">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-3 text-[10px] font-bold tracking-[0.2em] uppercase">
          <div className="flex items-center gap-2">
            <ShieldCheck size={14} className="text-stone-700" />
            <span>100% SECURE AUTHENTIC SNEAKER & STREETWEAR DROPS</span>
          </div>
          <div className="flex items-center gap-4">
            <span>WHATSAPP SUPPORT: +91 87718 18491</span>
            <span className="hidden sm:inline text-stone-400">|</span>
            <span>SHOWROOM RESERVE ACTIVE</span>
          </div>
        </div>
      </div>

      {/* Brand Grid Area */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 text-stone-400">
        
        {/* About Hub */}
        <div className="space-y-4">
          <span 
            onClick={() => handleLinkClick('home')}
            className="font-serif italic text-xl text-white cursor-pointer select-none block"
          >
            The Branded Hub
          </span>
          <p className="text-stone-400 leading-relaxed font-sans text-[11px] mt-2 tracking-wide">
            Bangalore's premium multi-brand streetwear destination. Showcasing handpicked certified drops, oversized fit collections, and physically authenticated footwear releases.
          </p>
          <div className="flex gap-1.5 pt-2">
            <a href="https://instagram.com/thebrandedhub.blr" target="_blank" rel="noopener noreferrer" className="p-2 bg-stone-900 hover:bg-stone-800 transition-all text-white border border-stone-800" title="Instagram">
              <Instagram size={13} />
            </a>
            <a href="https://facebook.com/thebrandedhub.blr" target="_blank" rel="noopener noreferrer" className="p-2 bg-stone-900 hover:bg-stone-800 transition-all text-white border border-stone-800" title="Facebook">
              <Facebook size={13} />
            </a>
          </div>
        </div>

        {/* Collections Links */}
        <div className="space-y-4">
          <h4 className="text-white font-sans font-bold tracking-widest uppercase text-[10px]">COLLECTIONS</h4>
          <ul className="space-y-2.5 text-[11px] tracking-widest font-semibold uppercase">
            <li>
              <button onClick={() => handleLinkClick('clothing', 'Oversized T-Shirts')} className="text-stone-400 hover:text-white transition-colors">
                Oversized T-Shirts
              </button>
            </li>
            <li>
              <button onClick={() => handleLinkClick('clothing', 'Hoodies')} className="text-stone-400 hover:text-white transition-colors">
                Heavyweight Hoodies
              </button>
            </li>
            <li>
              <button onClick={() => handleLinkClick('shoes', 'Air Jordan')} className="text-stone-400 hover:text-white transition-colors">
                Retro Air Jordans
              </button>
            </li>
            <li>
              <button onClick={() => handleLinkClick('shoes', 'Sport Shoes')} className="text-stone-400 hover:text-white transition-colors">
                Sport Shoes Catalog
              </button>
            </li>
            <li>
              <button onClick={() => handleLinkClick('accessories', null)} className="text-stone-400 hover:text-white transition-colors">
                Street Accessories
              </button>
            </li>
          </ul>
        </div>

        {/* Showrooms Address NAP */}
        <div className="space-y-4 col-span-1 md:col-span-2 lg:col-span-1">
          <h4 className="text-white font-sans font-bold tracking-widest uppercase text-[10px]">BANGALORE SHOWROOMS</h4>
          <div className="space-y-4 leading-relaxed text-[11px] text-stone-400 font-semibold uppercase tracking-wider">
            <div className="space-y-1">
              <p className="text-stone-200 font-bold">JAYANAGAR SHOWROOM</p>
              <p className="text-stone-500 font-medium normal-case tracking-normal">No. 42, 11th Main Rd, Jayanagar 3rd Block, Bangalore - 560011</p>
            </div>
            
            <div className="space-y-1">
              <p className="text-stone-200 font-bold">BTM LAYOUT SHOWROOM</p>
              <p className="text-stone-500 font-medium normal-case tracking-normal">No. 710, 100 Feet Ring Rd, BTM Layout 2nd Stage, Bangalore - 560076</p>
            </div>
          </div>
        </div>

        {/* Working Hours & Service */}
        <div className="space-y-4">
          <h4 className="text-white font-sans font-bold tracking-widest uppercase text-[10px]">SHOWROOM SCHEDULE</h4>
          <div className="space-y-3.5 text-[11px] text-stone-400 font-semibold uppercase tracking-wider">
            <div className="space-y-1">
              <p className="text-stone-200">OPEN DAILY</p>
              <p className="text-stone-500 normal-case tracking-normal">11:00 AM - 09:30 PM • 7 Days a week</p>
            </div>
            <div className="space-y-1">
              <p className="text-stone-200">SUPPORT ENQUIRY</p>
              <a href="mailto:support@thebrandedhub.in" className="text-stone-500 hover:text-white transition-colors normal-case tracking-normal block">
                support@thebrandedhub.in
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Footer Bottom copyright */}
      <div className="border-t border-stone-900 bg-black/40 text-[9px] text-stone-500 font-semibold tracking-[0.15em] uppercase">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex flex-col sm:flex-row justify-between items-center gap-4">
          <p>© {currentYear} THE BRANDED HUB BANGALORE INC. CURATED MODERN STREETWEAR DESIGN.</p>
          <div className="flex gap-4">
            <button onClick={() => handleLinkClick('about')} className="hover:text-white transition-colors">About Us</button>
            <button onClick={() => handleLinkClick('contact')} className="hover:text-white transition-colors">Store Locator</button>
            <span className="text-stone-800">|</span>
            <span className="text-stone-300">BANGALORE SUB-CULTURE DESTINATION</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
