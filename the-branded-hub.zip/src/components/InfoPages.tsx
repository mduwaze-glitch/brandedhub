import React, { useState } from 'react';
import { BlogPost } from '../types';
import { MapPin, Phone, Mail, Clock, Calendar, ArrowLeft, ArrowRight, ExternalLink, Sparkles, BookOpen, Star, Award } from 'lucide-react';

/* ==========================================================================
   1. ABOUT VIEW
   ========================================================================== */
export function AboutView() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16 animate-fade-in bg-[#fafaf9] text-[#111111]" id="about-view">
      <div className="text-center max-w-3xl mx-auto mb-16">
        <span className="text-[9px] font-bold text-stone-500 tracking-[0.25em] uppercase block mb-3 bg-[#ece8e1] px-3 py-1 inline-block">THE BRANDED HUB CHRONICLES</span>
        <h1 className="font-serif italic text-3xl sm:text-5xl font-light text-stone-900 leading-tight mb-6">
          Premium Streetwear • Authentic Subcultures
        </h1>
        <p className="text-xs sm:text-sm text-stone-500 leading-relaxed font-sans font-semibold uppercase tracking-wider">
          Founded in Jayanagar, Bangalore, in 2022. We are an omnichannel group of curators, designers, and sneakerheads bringing authentic streetwear to India.
        </p>
      </div>

      {/* Narrative block */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-12 sm:gap-16 items-center mb-20">
        <div>
          <span className="text-[9px] font-bold text-stone-400 tracking-[0.3em] uppercase block mb-2">OUR ORIGINS</span>
          <h2 className="font-serif italic text-xl sm:text-2xl text-stone-900 mb-4">
            From Cafe Trades to Multi-Brand Showrooms
          </h2>
          <div className="space-y-4 text-xs text-stone-600 leading-relaxed font-sans font-medium">
            <p>
              It started as an underground sneaker exchange in <strong className="font-bold text-stone-900">Koramangala</strong>. A handful of enthusiasts trading vintage kicks and custom heavyweight graphic tees. The passion was limitless, but the hurdles were massive: high customs duties, fake replica drops, and weeks of waiting.
            </p>
            <p>
              We established <strong className="font-bold text-stone-900">The Branded Hub</strong> to streamline this experience. By building direct procurement with certified global partners, we deliver authentic streetwear and sneaker drops on retro classics, paired with our premium loopback heavyweight custom garments.
            </p>
          </div>
        </div>
        <div className="aspect-[4/3] rounded-none border border-stone-200 overflow-hidden bg-stone-100">
          <img 
            src="https://images.unsplash.com/photo-1552346154-21d32810aba3?auto=format&fit=crop&q=80&w=800" 
            alt="The Branded Hub shoes wall" 
            className="w-full h-full object-cover object-center transform hover:scale-101 transition-transform duration-500"
          />
        </div>
      </div>

      {/* Flagship description */}
      <div className="bg-[#ece8e1] text-[#111111] rounded-none p-8 sm:p-12 mb-20 border border-stone-300">
        <div className="max-w-3xl">
          <span className="text-stone-500 font-sans text-[9px] font-bold tracking-[0.25em] uppercase block mb-3">📍 NAMMA BENGALURU LOCATIONS</span>
          <h2 className="font-serif italic text-2xl sm:text-3xl font-light mb-4 text-stone-900">
            Visit Our Experiential Showrooms
          </h2>
          <p className="text-stone-600 text-xs sm:text-sm leading-relaxed mb-8 font-medium">
            We believe streetwear is an organic, tactile experience. Come feel the 240 GSM weight of our oversized garments and review premium sneaker sizes under optimal studio lights.
          </p>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 border-t border-stone-300 pt-8 font-sans">
            <div>
              <h3 className="text-stone-900 text-xs font-bold uppercase tracking-widest mb-2">JAYANAGAR FLAGSHIP HQ</h3>
              <p className="text-xs text-stone-500 leading-relaxed font-medium">
                Located near the iconic 3rd Block, Jayanagar is our flagship lounge, featuring custom graphics displays, authenticated sizing bars, and minimalist lounge seating.
              </p>
            </div>
            <div>
              <h3 className="text-stone-900 text-xs font-bold uppercase tracking-widest mb-2">BTM LAYOUT VAULT SHOWROOM</h3>
              <p className="text-xs text-stone-500 leading-relaxed font-medium">
                Situated off the 100 Feet Ring Road, our BTM Layout showroom houses "The Vault" — Bangalore's premium catalog of hand-selected and verified street kicks.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}


/* ==========================================================================
   2. CONTACT VIEW (Local SEO GMB focused)
   ========================================================================== */
interface ContactViewProps {
  onNavigatePage: (page: string, sub: string | null) => void;
}

export function ContactView({ onNavigatePage }: ContactViewProps) {
  // Simple map interactive mock switcher
  const [activeMap, setActiveMap] = useState<'jayanagar' | 'btm'>('jayanagar');

  const storeDetails = {
    jayanagar: {
      name: "The Branded Hub - Jayanagar flagship",
      address: "No. 42, 11th Main Rd, Jayanagar 3rd Block, Bangalore, Karnataka - 560011",
      landmark: "Opposite Jayanagar Central Library, 2 mins from Metro Station",
      phone: "+91 87718 18491",
      hours: "11:00 AM - 09:30 PM (Open daily)",
      lat: "12.9279",
      lng: "77.5913"
    },
    btm: {
      name: "The Branded Hub - BTM Vault",
      address: "No. 710, 100 Feet Ring Rd, BTM Layout 2nd Stage, Bangalore, Karnataka - 560076",
      landmark: "Near BTM Lake Park Road intersection, Above Coffee Day",
      phone: "+91 87718 18491",
      hours: "11:00 AM - 09:30 PM (Open daily)",
      lat: "12.9166",
      lng: "77.6101"
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16 animate-fade-in bg-[#fafaf9] text-[#111111]" id="contact-view">
      <div className="text-center max-w-3xl mx-auto mb-12">
        <span className="text-[9px] font-bold text-stone-500 tracking-[0.25em] uppercase block mb-3 bg-[#ece8e1] px-3 py-1 inline-block">📍 STORE FINDER & INQUIRIES</span>
        <h1 className="font-serif italic text-3xl sm:text-5xl font-light text-stone-950 mb-4">
          Namma Bangalore Showrooms
        </h1>
        <p className="text-xs text-stone-500 font-sans font-semibold uppercase tracking-wider">
          Reserve your size online, pickup in-store or get complimentary home delivery inside Bangalore.
        </p>
      </div>

      {/* Main Split */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start mb-20">
        
        {/* Left Column: Hub Information */}
        <div className="lg:col-span-5 space-y-6">
          {/* Map Switcher Buttons */}
          <div className="grid grid-cols-2 gap-1 bg-stone-200 p-1 rounded-none border border-stone-300">
            <button
              onClick={() => setActiveMap('jayanagar')}
              className={`py-3 text-[10px] font-bold uppercase tracking-widest transition-all ${
                activeMap === 'jayanagar' ? 'bg-white text-stone-900' : 'text-stone-500 hover:text-stone-800'
              }`}
            >
              Jayanagar HQ
            </button>
            <button
              onClick={() => setActiveMap('btm')}
              className={`py-3 text-[10px] font-bold uppercase tracking-widest transition-all ${
                activeMap === 'btm' ? 'bg-white text-stone-900' : 'text-stone-500 hover:text-stone-800'
              }`}
            >
              BTM Vault
            </button>
          </div>

          {/* Active Store Card */}
          <div className="bg-white border border-stone-200 rounded-none p-6 sm:p-8">
            <span className="text-[8px] font-bold text-stone-400 tracking-widest uppercase block mb-1">
              SHOWROOM DETAILS
            </span>
            <h2 className="font-serif italic text-lg text-stone-900 mb-4">
              {storeDetails[activeMap].name}
            </h2>

            <div className="space-y-4 text-xs font-sans text-stone-600 font-medium">
              <div className="flex items-start gap-3">
                <MapPin className="text-stone-600 shrink-0 mt-0.5" size={14} />
                <div>
                  <p className="font-bold text-stone-900 uppercase tracking-widest text-[9px]">ADDRESS:</p>
                  <p className="text-stone-500 leading-relaxed mt-0.5">{storeDetails[activeMap].address}</p>
                  <p className="text-[9px] text-stone-400 mt-1 uppercase tracking-wider">Landmark: {storeDetails[activeMap].landmark}</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Phone className="text-stone-600 shrink-0 mt-0.5" size={14} />
                <div>
                  <p className="font-bold text-stone-900 uppercase tracking-widest text-[9px]">CUSTOMER HOTLINE:</p>
                  <a href={`tel:${storeDetails[activeMap].phone.replace(/\s+/g, '')}`} className="text-stone-950 font-bold font-mono tracking-widest text-xs inline-block mt-0.5 hover:underline">
                    {storeDetails[activeMap].phone}
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Clock className="text-stone-600 shrink-0 mt-0.5" size={14} />
                <div>
                  <p className="font-bold text-stone-900 uppercase tracking-widest text-[9px]">STORE SCHEDULE:</p>
                  <p className="text-stone-500 mt-0.5">{storeDetails[activeMap].hours}</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Mail className="text-stone-600 shrink-0 mt-0.5" size={14} />
                <div>
                  <p className="font-bold text-stone-900 uppercase tracking-widest text-[9px]">SUPPORT ENQUIRY:</p>
                  <a href="mailto:support@thebrandedhub.in" className="text-stone-500 hover:text-stone-950 hover:underline inline-block mt-0.5 font-mono">
                    support@thebrandedhub.in
                  </a>
                </div>
              </div>
            </div>

            <div className="mt-8 pt-6 border-t border-stone-100">
              <a
                href={`https://maps.google.com/?q=${encodeURIComponent(storeDetails[activeMap].address)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full bg-black hover:bg-stone-800 text-[#fafaf9] text-center text-[10px] font-bold uppercase tracking-widest py-3.5 flex items-center justify-center gap-1.5"
              >
                Get Directions <ExternalLink size={12} />
              </a>
            </div>
          </div>
        </div>

        {/* Right Column: Interactive map grid (beautiful modern abstract style) */}
        <div className="lg:col-span-7 bg-white border border-stone-200 rounded-none h-[350px] sm:h-[450px] overflow-hidden relative shadow-sm">
          <div className="absolute inset-0 p-6 flex flex-col justify-between z-10 select-none">
            <span className="bg-stone-900 text-white text-[8px] font-mono tracking-widest uppercase font-bold px-3 py-1.5">
              INTERACTIVE OUTLET SCHEMATIC (BANGALORE GMB GRID)
            </span>
            
            <div className="w-full flex items-center justify-center h-full relative">
              <div className="absolute inset-0 border-t border-b border-l border-r border-stone-200/50 grid grid-cols-6 grid-rows-6 pointer-events-none">
                {[...Array(36)].map((_, i) => <div key={i} className="border border-stone-200/30" />)}
              </div>
              
              <div className="absolute w-full h-1 bg-stone-150 rotate-12 transform origin-center" />
              <div className="absolute h-full w-1 bg-stone-150 -rotate-45 transform origin-center" />
              <div className="absolute w-full h-0.5 bg-stone-200 top-1/2" />
              
              <div className="absolute top-1/4 left-1/3 text-center">
                <span className="text-[8px] font-bold text-stone-300 uppercase tracking-widest">LALBAGH GARDENS</span>
              </div>
              <div className="absolute bottom-1/4 right-1/4 text-center">
                <span className="text-[8px] font-bold text-stone-300 uppercase tracking-widest">KORAMANGALA</span>
              </div>

              {activeMap === 'jayanagar' && (
                <div className="absolute top-[40%] left-[45%] text-center">
                  <div className="w-9 h-9 rounded-none bg-stone-900 text-white flex items-center justify-center border border-stone-300 mx-auto text-sm animate-bounce">
                    📍
                  </div>
                  <span className="bg-stone-900 text-white text-[8px] font-bold px-2 py-1 shadow mt-1.5 inline-block uppercase font-mono tracking-widest">
                    JAYANAGAR FLAGSHIP HQ
                  </span>
                </div>
              )}

              {activeMap === 'btm' && (
                <div className="absolute bottom-[35%] right-[40%] text-center">
                  <div className="w-9 h-9 rounded-none bg-stone-900 text-white flex items-center justify-center border border-stone-300 mx-auto text-sm animate-bounce">
                    📍
                  </div>
                  <span className="bg-stone-900 text-white text-[8px] font-bold px-2 py-1 shadow mt-1.5 inline-block uppercase font-mono tracking-widest">
                    BTM VAULT OUTLET
                  </span>
                </div>
              )}
            </div>

            <span className="text-[8px] font-mono font-semibold text-stone-400 self-end tracking-wider">
              LAT: {storeDetails[activeMap].lat}° N | LNG: {storeDetails[activeMap].lng}° E
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}


/* ==========================================================================
   3. STYLE GUIDE / BLOG VIEW
   ========================================================================== */
interface BlogViewProps {
  posts: BlogPost[];
  selectedPostSlug: string | null;
  onSelectPost: (slug: string | null) => void;
}

export function BlogView({ posts, selectedPostSlug, onSelectPost }: BlogViewProps) {
  const activePost = posts.find(p => p.slug === selectedPostSlug);

  // Single post reader layout
  if (activePost) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-10 sm:py-16 animate-fade-in bg-[#fafaf9] text-[#111111]" id="blog-reader">
        <button
          onClick={() => onSelectPost(null)}
          className="inline-flex items-center gap-1.5 text-[10px] font-bold text-stone-400 hover:text-stone-900 tracking-widest uppercase mb-8 font-sans"
        >
          <ArrowLeft size={13} /> Back to Style Guides
        </button>

        <article className="prose prose-stone max-w-none">
          <div className="flex items-center gap-3 text-[9px] font-sans font-bold text-stone-400 uppercase mb-4 tracking-widest">
            <span className="flex items-center gap-1"><Calendar size={11} /> {activePost.date}</span>
            <span>•</span>
            <span>{activePost.readTime}</span>
          </div>
          
          <h1 className="font-serif italic text-2xl sm:text-4xl font-light text-stone-950 leading-tight mb-6">
            {activePost.title}
          </h1>

          <div className="w-full aspect-[16/9] border border-stone-200 rounded-none overflow-hidden mb-10 bg-stone-100">
            <img src={activePost.image} alt={activePost.title} className="w-full h-full object-cover object-center" />
          </div>

          <div className="font-sans text-stone-600 text-xs sm:text-sm leading-relaxed space-y-6 font-medium tracking-wide">
            {activePost.content.split('\n\n').map((para, pIdx) => {
              if (para.startsWith('# ')) {
                return (
                  <h1 key={pIdx} className="font-serif text-lg sm:text-xl font-light text-stone-950 uppercase tracking-widest pt-4">
                    {para.replace('# ', '')}
                  </h1>
                );
              }
              if (para.startsWith('## ')) {
                return (
                  <h2 key={pIdx} className="font-serif text-base text-stone-900 uppercase tracking-widest pt-3">
                    {para.replace('## ', '')}
                  </h2>
                );
              }
              if (para.startsWith('- ')) {
                return (
                  <ul key={pIdx} className="list-disc pl-5 space-y-1.5 text-stone-600 font-medium">
                    {para.split('\n').map((li, lIdx) => (
                      <li key={lIdx} className="uppercase tracking-wide text-[10px] font-bold text-stone-800">{li.replace('- ', '')}</li>
                    ))}
                  </ul>
                );
              }
              return (
                <p key={pIdx} dangerouslySetInnerHTML={{ __html: para.replace(/\*\*(.*?)\*\*/g, '<strong class="font-bold text-stone-900">$1</strong>') }} />
              );
            })}
          </div>
        </article>
      </div>
    );
  }

  // Blog list view
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16 animate-fade-in bg-[#fafaf9] text-[#111111]" id="blog-dashboard">
      <div className="text-center max-w-3xl mx-auto mb-12 sm:mb-16">
        <span className="text-[9px] font-bold text-stone-500 tracking-[0.25em] uppercase block mb-3 bg-[#ece8e1] px-3 py-1 inline-block">THE STYLE CO. EDITORIAL</span>
        <h1 className="font-serif italic text-3xl sm:text-5xl font-light text-stone-950">
          Streetwear Chronicles
        </h1>
        <p className="text-xs text-stone-500 font-sans mt-3 font-semibold uppercase tracking-wider">
          Handpicked pairing style sheets, fit parameters, and Bangalore fashion reviews.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12">
        {posts.map(post => (
          <div
            key={post.id}
            onClick={() => onSelectPost(post.slug)}
            className="bg-white border border-stone-200 hover:border-black rounded-none overflow-hidden cursor-pointer group flex flex-col transition-colors duration-300"
          >
            <div className="relative aspect-[16/9] bg-stone-50 overflow-hidden shrink-0">
              <img 
                src={post.image} 
                alt={post.title} 
                className="w-full h-full object-cover object-center transform group-hover:scale-101 transition-transform duration-500"
                loading="lazy"
              />
              <span className="absolute top-4 left-4 bg-black text-[#fafaf9] text-[8px] font-sans font-black px-2.5 py-1 tracking-widest uppercase z-10 flex items-center gap-1">
                <BookOpen size={10} className="text-stone-300" /> STYLE HANDBOOK
              </span>
            </div>

            <div className="p-6 flex flex-col justify-between grow">
              <div>
                <div className="flex items-center gap-2 text-[9px] font-sans font-bold text-stone-400 uppercase mb-2 tracking-widest">
                  <span>{post.date}</span>
                  <span>•</span>
                  <span>{post.readTime}</span>
                </div>
                <h3 className="font-serif text-base sm:text-lg text-stone-900 group-hover:text-stone-500 transition-colors leading-snug mb-2">
                  {post.title}
                </h3>
                <p className="text-xs text-stone-500 line-clamp-2 leading-relaxed mb-4 font-sans font-medium">
                  {post.excerpt}
                </p>
              </div>

              <span className="inline-flex items-center gap-1 text-[10px] font-bold text-stone-900 group-hover:text-stone-600 uppercase tracking-widest font-sans">
                Read Guide <ArrowRight size={11} className="group-hover:translate-x-1 transition-transform" />
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
