import { Product, Order, BlogPost } from '../types';

const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'prod-aj1-chicago',
    name: "Nike Air Jordan 1 Retro High 'Chicago'",
    slug: 'nike-air-jordan-1-retro-high-chicago',
    category: 'Shoes',
    subcategory: 'Air Jordan',
    brand: 'Nike',
    price: 16995,
    discounted_price: 14995,
    description: "The Jordan 1 Retro High Chicago is a legendary sneaker that defined basketball and street culture. Featuring the classic Red, White, and Black color block, premium full-grain leather, and the iconic Wings logo. A grail for sneakerheads in Bangalore and across the globe.",
    images: [
      'https://images.unsplash.com/photo-1552346154-21d32810aba3?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1600185365483-26d7a4cc7519?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1597045566677-8cf032ed6634?auto=format&fit=crop&q=80&w=800'
    ],
    sizes: [
      { size: 'UK 7', stock: 3 },
      { size: 'UK 8', stock: 5 },
      { size: 'UK 9', stock: 8 },
      { size: 'UK 10', stock: 4 },
      { size: 'UK 11', stock: 0 }
    ],
    colors: ['Red', 'White', 'Black'],
    is_featured: true,
    status: 'active',
    created_at: new Date('2026-06-01').toISOString(),
    updated_at: new Date('2026-06-01').toISOString()
  },
  {
    id: 'prod-aj4-mil-black',
    name: "Jordan 4 Retro 'Military Black'",
    slug: 'jordan-4-retro-military-black',
    category: 'Shoes',
    subcategory: 'Air Jordan',
    brand: 'Jordan',
    price: 19995,
    discounted_price: 18495,
    description: "Striking a balance between clean court style and heavy street presence, the Jordan 4 Retro Military Black features smooth white leather with light grey suede overlays and neutral black accents on the TPU wings and midsole.",
    images: [
      'https://images.unsplash.com/photo-1597045566677-8cf032ed6634?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1552346154-21d32810aba3?auto=format&fit=crop&q=80&w=800'
    ],
    sizes: [
      { size: 'UK 7', stock: 2 },
      { size: 'UK 8', stock: 6 },
      { size: 'UK 9', stock: 4 },
      { size: 'UK 10', stock: 2 }
    ],
    colors: ['White', 'Grey', 'Black'],
    is_featured: true,
    status: 'active',
    created_at: new Date('2026-06-10').toISOString(),
    updated_at: new Date('2026-06-10').toISOString()
  },
  {
    id: 'prod-yeezy-onyx',
    name: "Adidas Yeezy Boost 350 V2 'Onyx'",
    slug: 'adidas-yeezy-boost-350-v2-onyx',
    category: 'Shoes',
    subcategory: 'Sport Shoes',
    brand: 'Adidas',
    price: 24999,
    discounted_price: 21999,
    description: "The Yeezy Boost 350 V2 Onyx offers a triple-black look with a Primeknit upper and signature Boost cushioning. Durable, ultra-comfortable, and highly coveted. Perfect for the fast-paced life in Namma Bengaluru.",
    images: [
      'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1608231387042-66d1773070a5?auto=format&fit=crop&q=80&w=800'
    ],
    sizes: [
      { size: 'UK 8', stock: 3 },
      { size: 'UK 9', stock: 5 },
      { size: 'UK 10', stock: 3 }
    ],
    colors: ['Black'],
    is_featured: true,
    status: 'active',
    created_at: new Date('2026-05-15').toISOString(),
    updated_at: new Date('2026-05-15').toISOString()
  },
  {
    id: 'prod-af1-white',
    name: "Nike Air Force 1 '07 All White",
    slug: 'nike-air-force-1-07-all-white',
    category: 'Shoes',
    subcategory: 'Sport Shoes',
    brand: 'Nike',
    price: 8295,
    description: "The classic triple white Air Force 1 '07. A versatile streetwear staple featuring durable leather overlays, heritage style, and air cushioning. Easily pairs with any oversized tee or cargo pants in your wardrobe.",
    images: [
      'https://images.unsplash.com/photo-1600185365483-26d7a4cc7519?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?auto=format&fit=crop&q=80&w=800'
    ],
    sizes: [
      { size: 'UK 6', stock: 4 },
      { size: 'UK 7', stock: 6 },
      { size: 'UK 8', stock: 12 },
      { size: 'UK 9', stock: 15 },
      { size: 'UK 10', stock: 10 },
      { size: 'UK 11', stock: 4 }
    ],
    colors: ['White'],
    is_featured: false,
    status: 'active',
    created_at: new Date('2026-04-20').toISOString(),
    updated_at: new Date('2026-04-20').toISOString()
  },
  {
    id: 'prod-tbh-brogues',
    name: "The Branded Hub Classic Brogues",
    slug: 'the-branded-hub-classic-brogues',
    category: 'Shoes',
    subcategory: 'Formal Shoes',
    brand: 'The Branded Hub',
    price: 4999,
    discounted_price: 3499,
    description: "Meticulously crafted from full-grain tan leather, these classic wingtip brogues deliver sharp office looks and solid evening style. Complete with high-rebound cushioning for all-day comfort around MG Road business hubs.",
    images: [
      'https://images.unsplash.com/photo-1533867617858-e7b97e060509?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1614252235316-8c857d38b5f4?auto=format&fit=crop&q=80&w=800'
    ],
    sizes: [
      { size: 'UK 7', stock: 3 },
      { size: 'UK 8', stock: 8 },
      { size: 'UK 9', stock: 6 },
      { size: 'UK 10', stock: 4 }
    ],
    colors: ['Tan', 'Brown'],
    is_featured: false,
    status: 'active',
    created_at: new Date('2026-06-05').toISOString(),
    updated_at: new Date('2026-06-05').toISOString()
  },
  {
    id: 'prod-tokyo-tee',
    name: "Heavyweight Graphic Oversized Tee 'Tokyo Drift'",
    slug: 'heavyweight-graphic-oversized-tee-tokyo-drift',
    category: 'Clothing',
    subcategory: 'Oversized T-Shirts',
    brand: 'The Branded Hub',
    price: 1499,
    discounted_price: 999,
    description: "Cut from ultra-heavy 240 GSM organic cotton with a dry, luxury-grade hand feel. Features a high-density puff print representing retro Japanese motor clubs. Tailored boxy silhouette, dropped shoulders, and a thick rib neck. Essential high-end street drip.",
    images: [
      'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&q=80&w=800'
    ],
    sizes: [
      { size: 'S', stock: 10 },
      { size: 'M', stock: 15 },
      { size: 'L', stock: 20 },
      { size: 'XL', stock: 12 },
      { size: 'XXL', stock: 5 }
    ],
    colors: ['Vintage Black', 'White'],
    is_featured: true,
    status: 'active',
    created_at: new Date('2026-06-12').toISOString(),
    updated_at: new Date('2026-06-12').toISOString()
  },
  {
    id: 'prod-aesthetic-tee',
    name: "Vintage Washed Acid Tee 'Aesthetic'",
    slug: 'vintage-washed-acid-tee-aesthetic',
    category: 'Clothing',
    subcategory: 'Oversized T-Shirts',
    brand: 'The Branded Hub',
    price: 1299,
    description: "Premium acid-wash finish giving it a soft, worn-in look from day one. Heavily dropped shoulder seam and extra width in the sleeves for that perfect bagginess. Features screen-printed abstract line art on the chest.",
    images: [
      'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&q=80&w=800'
    ],
    sizes: [
      { size: 'S', stock: 8 },
      { size: 'M', stock: 12 },
      { size: 'L', stock: 18 },
      { size: 'XL', stock: 10 }
    ],
    colors: ['Acid Charcoal'],
    is_featured: true,
    status: 'active',
    created_at: new Date('2026-06-18').toISOString(),
    updated_at: new Date('2026-06-18').toISOString()
  },
  {
    id: 'prod-midnight-tee',
    name: "Premium Boxy Fit T-Shirt 'Midnight'",
    slug: 'premium-boxy-fit-t-shirt-midnight',
    category: 'Clothing',
    subcategory: 'T-Shirts',
    brand: 'The Branded Hub',
    price: 999,
    discounted_price: 799,
    description: "A clean, solid boxy fit t-shirt built for daily layering. Made with 100% long-staple Indian cotton, 200 GSM, delivering long-lasting structural integrity and a super smooth drape. Available in Deep Indigo Midnight Blue.",
    images: [
      'https://images.unsplash.com/photo-1562157873-818bc0726f68?auto=format&fit=crop&q=80&w=800'
    ],
    sizes: [
      { size: 'S', stock: 15 },
      { size: 'M', stock: 25 },
      { size: 'L', stock: 30 },
      { size: 'XL', stock: 15 }
    ],
    colors: ['Midnight Blue', 'Charcoal'],
    is_featured: false,
    status: 'active',
    created_at: new Date('2026-05-20').toISOString(),
    updated_at: new Date('2026-05-20').toISOString()
  },
  {
    id: 'prod-blr-drip-shirt',
    name: "Streetwear Flannel Check Shirt 'Bangalore Drip'",
    slug: 'streetwear-flannel-check-shirt-bangalore-drip',
    category: 'Clothing',
    subcategory: 'Shirts',
    brand: 'The Branded Hub',
    price: 2499,
    discounted_price: 1899,
    description: "An oversized heavy cotton flannel button-down designed to be worn open as an outer shirt. Featuring custom green and black checks, double utility front pockets, and a soft brushed surface. Tailored for cooler Bangalore evenings.",
    images: [
      'https://images.unsplash.com/photo-1598033129183-c4f50c736f10?auto=format&fit=crop&q=80&w=800'
    ],
    sizes: [
      { size: 'S', stock: 5 },
      { size: 'M', stock: 12 },
      { size: 'L', stock: 15 },
      { size: 'XL', stock: 8 }
    ],
    colors: ['Forest Green', 'Black Checks'],
    is_featured: true,
    status: 'active',
    created_at: new Date('2026-06-22').toISOString(),
    updated_at: new Date('2026-06-22').toISOString()
  },
  {
    id: 'prod-hoodie-graphite',
    name: "Heavy Hooded Sweatshirt 'Graphite'",
    slug: 'heavy-hooded-sweatshirt-graphite',
    category: 'Clothing',
    subcategory: 'Hoodies',
    brand: 'The Branded Hub',
    price: 3499,
    discounted_price: 2499,
    description: "Crafted from 400 GSM double-fleece cotton, this heavyweight hoodie keeps its shape and keeps you cozy. Designed with double-lined structural hoods, custom drawcords with metal tips, and a spacious front kangaroo pocket.",
    images: [
      'https://images.unsplash.com/photo-1556821840-3a63f95609a7?auto=format&fit=crop&q=80&w=800'
    ],
    sizes: [
      { size: 'S', stock: 8 },
      { size: 'M', stock: 15 },
      { size: 'L', stock: 12 },
      { size: 'XL', stock: 6 }
    ],
    colors: ['Graphite Grey', 'Onyx'],
    is_featured: true,
    status: 'active',
    created_at: new Date('2026-06-08').toISOString(),
    updated_at: new Date('2026-06-08').toISOString()
  },
  {
    id: 'prod-cargo-pants',
    name: "Retro Utility Cargo Pants 'Tech'",
    slug: 'retro-utility-cargo-pants-tech',
    category: 'Clothing',
    subcategory: 'Pants',
    brand: 'The Branded Hub',
    price: 2999,
    discounted_price: 2299,
    description: "Engineered with heavy-duty ripstop canvas, elasticated toggles at the ankles, and 6 spacious 3D utility pockets. Offers a comfortable relaxed fit from thigh to knee with a slightly tapered profile at the bottom.",
    images: [
      'https://images.unsplash.com/photo-1517462964-21fdcec3f25b?auto=format&fit=crop&q=80&w=800'
    ],
    sizes: [
      { size: '30', stock: 5 },
      { size: '32', stock: 10 },
      { size: '34', stock: 12 },
      { size: '36', stock: 4 }
    ],
    colors: ['Olive Green', 'Matte Black'],
    is_featured: false,
    status: 'active',
    created_at: new Date('2026-06-11').toISOString(),
    updated_at: new Date('2026-06-11').toISOString()
  },
  {
    id: 'prod-leather-wallet',
    name: "Minimalist Full-Grain Leather Wallet",
    slug: 'minimalist-full-grain-leather-wallet',
    category: 'Accessories',
    subcategory: 'Wallets',
    brand: 'The Branded Hub',
    price: 1999,
    discounted_price: 1299,
    description: "A super sleek, RFID-blocking card sleeve handcrafted with vegetable-tanned premium leather. Features 4 quick-access card slots and a magnetic cash clip. Beautiful hand-stitching with reinforced nylon threading.",
    images: [
      'https://images.unsplash.com/photo-1627124156297-9d42a5934cd4?auto=format&fit=crop&q=80&w=800'
    ],
    sizes: [
      { size: 'One Size', stock: 25 }
    ],
    colors: ['Tan', 'Dark Espresso'],
    is_featured: false,
    status: 'active',
    created_at: new Date('2026-05-05').toISOString(),
    updated_at: new Date('2026-05-05').toISOString()
  },
  {
    id: 'prod-tactical-belt',
    name: "Urban Streetwear Tactical Belt",
    slug: 'urban-streetwear-tactical-belt',
    category: 'Accessories',
    subcategory: 'Belts',
    brand: 'The Branded Hub',
    price: 1199,
    discounted_price: 799,
    description: "Built with military-grade heavy nylon webbing and a quick-release matte black cobra-style alloy buckle. Fully adjustable fit up to 42-inch waist size. Perfect utility accent to complete your cargo pants outfit.",
    images: [
      'https://images.unsplash.com/photo-1614162692292-7ac56d7f7f1e?auto=format&fit=crop&q=80&w=800'
    ],
    sizes: [
      { size: 'Adjustable', stock: 30 }
    ],
    colors: ['Black', 'Tactical Tan'],
    is_featured: false,
    status: 'active',
    created_at: new Date('2026-05-18').toISOString(),
    updated_at: new Date('2026-05-18').toISOString()
  },
  {
    id: 'prod-denim-hat',
    name: "Distressed Denim Dad Hat 'Core'",
    slug: 'distressed-denim-dad-hat-core',
    category: 'Accessories',
    subcategory: 'Hats',
    brand: 'The Branded Hub',
    price: 1499,
    discounted_price: 999,
    description: "Washed soft denim baseball cap featuring distressed fray details and an adjustable brass metal buckle closure. Embossed tonal embroidery on the front panel. A relaxed piece designed for sunny Bangalore days.",
    images: [
      'https://images.unsplash.com/photo-1588850561407-ed78c282e89b?auto=format&fit=crop&q=80&w=800'
    ],
    sizes: [
      { size: 'One Size', stock: 15 }
    ],
    colors: ['Light Wash Denim', 'Acid Wash Black'],
    is_featured: false,
    status: 'active',
    created_at: new Date('2026-06-03').toISOString(),
    updated_at: new Date('2026-06-03').toISOString()
  }
];

const INITIAL_BLOG_POSTS: BlogPost[] = [
  {
    id: 'blog-1',
    title: "Bangalore's Streetwear Boom: A Deep Dive into Sneaker Culture",
    slug: 'bangalores-streetwear-boom-sneaker-culture',
    excerpt: "Explore how Namma Bengaluru became the hub of India's energetic sneakerhead movement and urban fashion revolution.",
    date: "June 25, 2026",
    readTime: "4 min read",
    image: "https://images.unsplash.com/photo-1552346154-21d32810aba3?auto=format&fit=crop&q=80&w=800",
    content: `
# Bangalore's Streetwear Boom: A Deep Dive into Sneaker Culture

From the bustling lanes of **Indiranagar** to the student vibes of **Koramangala**, a massive cultural shift has swept across Bangalore. Traditional casual wear is rapidly making room for bold, graphic-heavy streetwear, oversized silhouettes, and high-heat kicks.

## The Sneaker Capital of the South?
For years, Delhi and Mumbai dominated India's high-fashion circles. But when it comes to grassroots street-level drip, Bangalore is carving out its own legacy. With tech-forward youth, thriving indie music circles, and a booming coffee shop culture, the city provides the perfect backdrop for sneakerheads.

Walk into any popular craft brewery or third-wave cafe in **Jayanagar** or **Koramangala**, and you are bound to spot pairs of Jordan 1s, Yeezy Boosts, and Nike Dunks. It's not just a hobby anymore; it's a dynamic community.

## Blending Indian Aesthetics with Urban Utility
What makes Bangalore streetwear unique is how it adapts to the local environment. Because of our beautiful year-round mild climate, layering with lightweight heavyweight cotton shirts or throwing an open flannel over a vintage-washed 240 GSM tee is the perfect go-to look.

Our premium oversized graphic shirts are tailor-made for this exact aesthetic. They look effortless, feel incredible, and hold their structure through countless rides down Outer Ring Road.

## Come Visit Us!
At **The Branded Hub**, we bring the absolute best of sneaker and apparel curation directly to you. Visit our offline stores in **Jayanagar (near 4th Block)** and **BTM Layout** to feel the heavyweight fabrics and try on your dream kicks in person.
    `
  },
  {
    id: 'blog-2',
    title: "How to Style Oversized Tee: The Ultimate Streetwear Fit Guide",
    slug: 'how-to-style-oversized-tee-streetwear-guide',
    excerpt: "Struggling to find the right balance? Learn how to style oversized cotton t-shirts without looking drowned.",
    date: "June 14, 2026",
    readTime: "3 min read",
    image: "https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&q=80&w=800",
    content: `
# How to Style Oversized Tees: The Ultimate Fit Guide

Oversized t-shirts are the absolute foundation of modern streetwear. But there's a big difference between looking intentionally styled and simply wearing a shirt that's three sizes too big. Here's how to master the fit.

## 1. Look for the 'Dropped Shoulder'
A true streetwear oversized tee isn't just wide; it's specifically engineered. The shoulder seams should sit lower down on your arm, and the neck ribbing should be tight and structured (around 1.2 inches thick). If the neck is loose, the tee will look sloppy.

## 2. Balance the Proportions
The golden rule of streetwear styling is **balancing silhouettes**:
- If you're wearing a very wide, boxy tee, pair it with structured bottoms like **Retro Cargo Pants** or fitted denim to create a neat, rugged shape.
- If you want a full baggy aesthetic, ensure your pants taper slightly at the ankle (using cuffs or elastic toggles) so they stack perfectly on your sneakers.

## 3. Play with Texture and Weight
A premium oversized tee should be made from **240 GSM heavy cotton**. The heavy weight allows the fabric to drape rigidly off your chest and shoulders, hiding body lines and giving you that crisp streetwear silhouette. Pair it with high-rise sneakers like Air Jordan 1s to ground the look.

Check out our latest **Heavyweight Graphic Series** at **The Branded Hub** stores or online to upgrade your daily rotation!
    `
  }
];

// Helper to initialize LocalStorage if empty
const initLocalStorage = () => {
  if (!localStorage.getItem('tbh_products')) {
    localStorage.setItem('tbh_products', JSON.stringify(INITIAL_PRODUCTS));
  }
  if (!localStorage.getItem('tbh_orders')) {
    localStorage.setItem('tbh_orders', JSON.stringify([]));
  }
  if (!localStorage.getItem('tbh_blog')) {
    localStorage.setItem('tbh_blog', JSON.stringify(INITIAL_BLOG_POSTS));
  }
};

// Data Layer APIs
export const getProducts = (): Product[] => {
  initLocalStorage();
  const prods = localStorage.getItem('tbh_products');
  return prods ? JSON.parse(prods) : [];
};

export const getProductBySlug = (slug: string): Product | undefined => {
  const products = getProducts();
  return products.find(p => p.slug === slug);
};

export const createProduct = (product: Product): void => {
  const products = getProducts();
  products.unshift(product);
  localStorage.setItem('tbh_products', JSON.stringify(products));
};

export const updateProduct = (updatedProduct: Product): void => {
  const products = getProducts();
  const index = products.findIndex(p => p.id === updatedProduct.id);
  if (index !== -1) {
    products[index] = {
      ...updatedProduct,
      updated_at: new Date().toISOString()
    };
    localStorage.setItem('tbh_products', JSON.stringify(products));
  }
};

export const deleteProduct = (id: string): void => {
  const products = getProducts();
  const filtered = products.filter(p => p.id !== id);
  localStorage.setItem('tbh_products', JSON.stringify(filtered));
};

export const updateStock = (productId: string, sizeName: string, quantity: number): void => {
  const products = getProducts();
  const index = products.findIndex(p => p.id === productId);
  if (index !== -1) {
    const updatedSizes = products[index].sizes.map(s => {
      if (s.size === sizeName) {
        return { ...s, stock: Math.max(0, quantity) };
      }
      return s;
    });
    
    // Also update overall status if entirely out of stock
    const totalStock = updatedSizes.reduce((acc, s) => acc + s.stock, 0);
    const status = totalStock === 0 ? 'out-of-stock' : products[index].status;

    products[index] = {
      ...products[index],
      sizes: updatedSizes,
      status: status as 'active' | 'out-of-stock' | 'archived',
      updated_at: new Date().toISOString()
    };
    localStorage.setItem('tbh_products', JSON.stringify(products));
  }
};

export const bulkMarkOutOfStock = (productIds: string[]): void => {
  const products = getProducts();
  const updated = products.map(p => {
    if (productIds.includes(p.id)) {
      const updatedSizes = p.sizes.map(s => ({ ...s, stock: 0 }));
      return {
        ...p,
        sizes: updatedSizes,
        status: 'out-of-stock' as const,
        updated_at: new Date().toISOString()
      };
    }
    return p;
  });
  localStorage.setItem('tbh_products', JSON.stringify(updated));
};

export const bulkArchiveProducts = (productIds: string[]): void => {
  const products = getProducts();
  const updated = products.map(p => {
    if (productIds.includes(p.id)) {
      return {
        ...p,
        status: 'archived' as const,
        updated_at: new Date().toISOString()
      };
    }
    return p;
  });
  localStorage.setItem('tbh_products', JSON.stringify(updated));
};

// Orders (WhatsApp logs)
export const getOrders = (): Order[] => {
  initLocalStorage();
  const orders = localStorage.getItem('tbh_orders');
  return orders ? JSON.parse(orders) : [];
};

export const createOrder = (order: Order): void => {
  const orders = getOrders();
  orders.unshift(order);
  localStorage.setItem('tbh_orders', JSON.stringify(orders));
};

export const updateOrderStatus = (orderId: string, status: 'pending' | 'completed' | 'cancelled'): void => {
  const orders = getOrders();
  const index = orders.findIndex(o => o.id === orderId);
  if (index !== -1) {
    orders[index].status = status;
    localStorage.setItem('tbh_orders', JSON.stringify(orders));
  }
};

// Blog
export const getBlogPosts = (): BlogPost[] => {
  initLocalStorage();
  const posts = localStorage.getItem('tbh_blog');
  return posts ? JSON.parse(posts) : [];
};

export const getBlogPostBySlug = (slug: string): BlogPost | undefined => {
  const posts = getBlogPosts();
  return posts.find(p => p.slug === slug);
};
