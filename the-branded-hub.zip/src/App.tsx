import React, { useState, useEffect, useMemo } from 'react';
import Navbar from './components/Navbar';
import HomeView from './components/HomeView';
import ListingView from './components/ListingView';
import PdpView from './components/PdpView';
import AdminView from './components/AdminView';
import { AboutView, ContactView, BlogView } from './components/InfoPages';
import Footer from './components/Footer';
import CartDrawer from './components/CartDrawer';

import { Product, CartItem, Order } from './types';
import {
  getProducts,
  getProductBySlug,
  createProduct,
  updateProduct,
  deleteProduct,
  updateStock,
  getOrders,
  createOrder,
  updateOrderStatus,
  getBlogPosts,
  bulkMarkOutOfStock,
  bulkArchiveProducts
} from './data/store';

export default function App() {
  // Navigation Routing States
  const [currentPage, setCurrentPage] = useState<string>('home');
  const [currentSubcategory, setCurrentSubcategory] = useState<string | null>(null);
  const [selectedProductSlug, setSelectedProductSlug] = useState<string | null>(null);
  const [selectedBlogPostSlug, setSelectedBlogPostSlug] = useState<string | null>(null);

  // Core Data Lists
  const [products, setProducts] = useState<Product[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [blogPosts, setBlogPosts] = useState([]);

  // Shopping Cart & Drawer States
  const [cart, setCart] = useState<CartItem[]>([]);
  const [cartOpen, setCartOpen] = useState(false);

  // Global Search State
  const [searchQuery, setSearchQuery] = useState('');

  // Initial Sync and Load
  useEffect(() => {
    setProducts(getProducts());
    setOrders(getOrders());
    setBlogPosts(getBlogPosts() as any);

    // Initial LocalStorage Cart Sync
    const savedCart = localStorage.getItem('tbh_cart');
    if (savedCart) {
      setCart(JSON.parse(savedCart));
    }
  }, []);

  const cartCount = useMemo(() => {
    return cart.reduce((acc, item) => acc + item.quantity, 0);
  }, [cart]);

  // Sync Cart to LocalStorage
  const saveCart = (newCart: CartItem[]) => {
    setCart(newCart);
    localStorage.setItem('tbh_cart', JSON.stringify(newCart));
  };

  const handleNavigatePage = (page: string, sub: string | null = null) => {
    setCurrentPage(page);
    setCurrentSubcategory(sub);
    setSelectedProductSlug(null);
    setSelectedBlogPostSlug(null);
    setSearchQuery('');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectProduct = (slug: string) => {
    setSelectedProductSlug(slug);
    setCurrentPage('product');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectBlogPost = (slug: string | null) => {
    setSelectedBlogPostSlug(slug);
    setCurrentPage('blog');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Cart operations
  const handleAddToCart = (product: Product, size: string, qty: number) => {
    const existingIndex = cart.findIndex(
      item => item.product.id === product.id && item.selectedSize === size
    );

    let updatedCart = [...cart];
    if (existingIndex !== -1) {
      updatedCart[existingIndex].quantity += qty;
    } else {
      updatedCart.push({
        product,
        selectedSize: size,
        quantity: qty
      });
    }

    saveCart(updatedCart);
    setCartOpen(true); // Open drawer on addition for strong visual reinforcement
  };

  const handleUpdateQty = (productId: string, size: string, qty: number) => {
    if (qty <= 0) {
      handleRemoveItem(productId, size);
      return;
    }

    // Upper bound checks against actual product stock remaining!
    const product = products.find(p => p.id === productId);
    if (product) {
      const sizeMatch = product.sizes.find(s => s.size === size);
      const stockAvailable = sizeMatch ? sizeMatch.stock : 0;
      if (qty > stockAvailable) {
        alert(`Sorry, only ${stockAvailable} item(s) are physically available for size ${size}.`);
        return;
      }
    }

    const updatedCart = cart.map(item => {
      if (item.product.id === productId && item.selectedSize === size) {
        return { ...item, quantity: qty };
      }
      return item;
    });
    saveCart(updatedCart);
  };

  const handleRemoveItem = (productId: string, size: string) => {
    const updatedCart = cart.filter(
      item => !(item.product.id === productId && item.selectedSize === size)
    );
    saveCart(updatedCart);
  };

  // Log transaction details silently on PDP Checkout
  const handleLogInquiry = (customerName: string, customerPhone: string, selectedSize: string, qty: number) => {
    if (!selectedProductSlug) return;
    const activeProduct = getProductBySlug(selectedProductSlug);
    if (!activeProduct) return;

    const price = activeProduct.discounted_price || activeProduct.price;

    const newInquiry: Order = {
      id: 'BLR-' + Math.floor(100000 + Math.random() * 900000),
      customerName,
      customerPhone,
      items: [
        {
          productId: activeProduct.id,
          productName: activeProduct.name,
          brand: activeProduct.brand,
          selectedSize,
          quantity: qty,
          priceAtPurchase: price
        }
      ],
      totalPrice: price * qty,
      status: 'pending',
      createdAt: new Date().toISOString()
    };

    createOrder(newInquiry);
    setOrders(getOrders()); // Refresh dashboard list in memory
  };

  // Log Cart bundle inquire logs
  const handleCartCheckoutLog = (customerName: string, customerPhone: string) => {
    if (cart.length === 0) return;

    const cartSubtotal = cart.reduce((sum, item) => {
      const activePrice = item.product.discounted_price || item.product.price;
      return sum + (activePrice * item.quantity);
    }, 0);

    const shippingCharge = cartSubtotal >= 1999 ? 0 : 150;

    const newOrder: Order = {
      id: 'BLR-' + Math.floor(100000 + Math.random() * 900000),
      customerName,
      customerPhone,
      items: cart.map(item => {
        const activePrice = item.product.discounted_price || item.product.price;
        return {
          productId: item.product.id,
          productName: item.product.name,
          brand: item.product.brand,
          selectedSize: item.selectedSize,
          quantity: item.quantity,
          priceAtPurchase: activePrice
        };
      }),
      totalPrice: cartSubtotal + shippingCharge,
      status: 'pending',
      createdAt: new Date().toISOString()
    };

    createOrder(newOrder);
    setOrders(getOrders()); // Sync
    saveCart([]); // Flush cart upon a successful checkout!
  };

  // Admin DB operations callbacks
  const handleAdminCreate = (p: Product) => {
    createProduct(p);
    setProducts(getProducts());
  };

  const handleAdminUpdate = (p: Product) => {
    updateProduct(p);
    setProducts(getProducts());
  };

  const handleAdminDelete = (id: string) => {
    deleteProduct(id);
    setProducts(getProducts());
  };

  const handleAdminUpdateStock = (prodId: string, sizeName: string, qty: number) => {
    updateStock(prodId, sizeName, qty);
    setProducts(getProducts());
  };

  const handleAdminBulkOutOfStock = (ids: string[]) => {
    bulkMarkOutOfStock(ids);
    setProducts(getProducts());
  };

  const handleAdminBulkArchive = (ids: string[]) => {
    bulkArchiveProducts(ids);
    setProducts(getProducts());
  };

  const handleAdminUpdateOrderStatus = (orderId: string, status: 'pending' | 'completed' | 'cancelled') => {
    updateOrderStatus(orderId, status);
    setOrders(getOrders());
  };

  // Navigation PDP context helper
  const pdpProduct = useMemo(() => {
    if (currentPage === 'product' && selectedProductSlug) {
      return products.find(p => p.slug === selectedProductSlug);
    }
    return undefined;
  }, [products, currentPage, selectedProductSlug]);

  const pdpRelatedProducts = useMemo(() => {
    if (!pdpProduct) return [];
    return products
      .filter(p => p.category === pdpProduct.category && p.id !== pdpProduct.id && p.status === 'active')
      .slice(0, 4);
  }, [products, pdpProduct]);

  return (
    <div className="flex flex-col min-h-screen">
      {/* Global Top Navbar Navigation */}
      <Navbar
        currentPage={currentPage}
        setCurrentPage={setCurrentPage}
        setCurrentSubcategory={setCurrentSubcategory}
        cartCount={cartCount}
        setCartOpen={setCartOpen}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
      />

      {/* Main Content Area Routing */}
      <main className="flex-grow">
        {(() => {
          // 1. Home Page Routing
          if (currentPage === 'home') {
            return (
              <HomeView
                products={products}
                onSelectProduct={handleSelectProduct}
                onNavigatePage={handleNavigatePage}
              />
            );
          }

          // 2. Collections / Listings Router (Clothing, Shoes, Accessories)
          if (currentPage === 'clothing' || currentPage === 'shoes' || currentPage === 'accessories') {
            const catMap = {
              clothing: 'Clothing',
              shoes: 'Shoes',
              accessories: 'Accessories'
            };
            return (
              <ListingView
                products={products}
                category={catMap[currentPage as 'clothing' | 'shoes' | 'accessories'] as any}
                subcategory={currentSubcategory}
                onSelectProduct={handleSelectProduct}
                searchQuery={searchQuery}
              />
            );
          }

          // 3. Product Detail Page (PDP)
          if (currentPage === 'product') {
            if (pdpProduct) {
              return (
                <PdpView
                  product={pdpProduct}
                  onAddToCart={handleAddToCart}
                  relatedProducts={pdpRelatedProducts}
                  onSelectProduct={handleSelectProduct}
                  onLogInquiry={handleLogInquiry}
                />
              );
            } else {
              // product not found, fallback to 404
              return <div className="max-w-md mx-auto text-center py-24 select-none">
                <span className="text-5xl block mb-4">👟</span>
                <h2 className="font-display text-xl font-bold uppercase mb-2">Drop listing not found</h2>
                <p className="text-stone-500 text-xs mb-6 leading-relaxed">The requested limited-edition sneaker or streetwear piece was archived or moved. Check back soon for restocking.</p>
                <button onClick={() => handleNavigatePage('clothing')} className="bg-stone-900 text-white font-bold text-xs uppercase tracking-wider px-5 py-3 rounded">Browse clothing catalog</button>
              </div>;
            }
          }

          // 4. About Us Page
          if (currentPage === 'about') {
            return <AboutView />;
          }

          // 5. Contact / Store locator Map Embeds Page
          if (currentPage === 'contact') {
            return <ContactView onNavigatePage={handleNavigatePage} />;
          }

          // 6. Blog Style Guides
          if (currentPage === 'blog') {
            return (
              <BlogView
                posts={blogPosts}
                selectedPostSlug={selectedBlogPostSlug}
                onSelectPost={handleSelectBlogPost}
              />
            );
          }

          // 7. Gated Admin Suite
          if (currentPage === 'admin') {
            return (
              <AdminView
                products={products}
                orders={orders}
                onCreateProduct={handleAdminCreate}
                onUpdateProduct={handleAdminUpdate}
                onDeleteProduct={handleAdminDelete}
                onUpdateStock={handleAdminUpdateStock}
                onBulkOutOfStock={handleAdminBulkOutOfStock}
                onBulkArchive={handleAdminBulkArchive}
                onUpdateOrderStatus={handleAdminUpdateOrderStatus}
              />
            );
          }

          // Fallback 404 View
          return (
            <div className="max-w-md mx-auto text-center py-24 px-4 select-none" id="fallback-404">
              <span className="text-6xl block mb-4">🔍</span>
              <h2 className="font-display text-xl font-black uppercase text-stone-900 mb-2">PAGE NOT FOUND</h2>
              <p className="text-stone-500 text-xs leading-relaxed mb-6">
                The requested URL does not exist or has been archived. Get back to our Bangalore catalog loops immediately.
              </p>
              <button
                onClick={() => handleNavigatePage('home')}
                className="bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold uppercase tracking-widest px-6 py-3.5 rounded shadow"
              >
                Return to Home Drip
              </button>
            </div>
          );
        })()}
      </main>

      {/* Global Shopping Bag Slider Drawer */}
      <CartDrawer
        isOpen={cartOpen}
        onClose={() => setCartOpen(false)}
        cart={cart}
        onUpdateQty={handleUpdateQty}
        onRemoveItem={handleRemoveItem}
        onCheckout={handleCartCheckoutLog}
      />

      {/* Global Consistent Footer Cite block */}
      <Footer onNavigatePage={handleNavigatePage} />
    </div>
  );
}
